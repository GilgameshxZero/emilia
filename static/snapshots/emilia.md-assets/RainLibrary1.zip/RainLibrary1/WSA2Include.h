/*
Deprecated
*/

//Use this include when designing WSA2 programs.

#pragma once
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif

#ifndef _WINSOCKAPI_ //stops windows.h and winsock2.h from interfering in their definitions, sometimes
#define _WINSOCKAPI_
#endif

#include "WindowsLAMInclude.h"

#include <winsock2.h>
#include <ws2tcpip.h>
#include <iphlpapi.h>

#pragma comment(lib, "Ws2_32.lib")