#include <cassert>
#include <string>
#include <Windows.h>
#include <windowsx.h>
#include "ScrollBar.h"
#include "Window.h"

namespace Rain
{
	ScrollBar::ScrollBar () : NORMAL (0), HOVER (1), DOWN (2)
	{
	}
	ScrollBar::~ScrollBar ()
	{
	}

	void ScrollBar::Initialize (HWND parent)
	{
		Window::Initialize (CS_HREDRAW | CS_VREDRAW);
		SetStyle (WS_CHILD);
		SetParent (parent);

		RedefineMessage (WM_PAINT, static_cast<LRESULT (Rain::Window::*) (WPARAM, LPARAM)>(&ScrollBar::OnPaint));
		RedefineMessage (WM_LBUTTONUP, static_cast<LRESULT (Rain::Window::*) (WPARAM, LPARAM)>(&ScrollBar::OnLButtonUp));
		RedefineMessage (WM_LBUTTONDOWN, static_cast<LRESULT (Rain::Window::*) (WPARAM, LPARAM)>(&ScrollBar::OnLButtonDown));
		RedefineMessage (WM_MOUSEMOVE, static_cast<LRESULT (Rain::Window::*) (WPARAM, LPARAM)>(&ScrollBar::OnMouseMove));
		RedefineMessage (WM_MOUSEWHEEL, static_cast<LRESULT (Rain::Window::*) (WPARAM, LPARAM)>(&ScrollBar::OnMouseWheel));
		RedefineMessage (WM_ERASEBKGND, static_cast<LRESULT (Rain::Window::*) (WPARAM, LPARAM)>(&ScrollBar::OnEraseBkgnd));
		RedefineMessage (WM_SIZE, static_cast<LRESULT (Rain::Window::*) (WPARAM, LPARAM)>(&ScrollBar::OnSize));

		//Re-initialize local variables here.
		scroll_const = static_cast<double>(WHEEL_DELTA);
		normal_color = RGB (40,40,40);
		hover_color = RGB (50,50,50);
		down_color = RGB (50,50,90);
		bk_color = RGB (20,20,20);
		state = NORMAL;
		pos = 0;
		offset_y = 0;
		bord_x = 7;
		bord_y = 7;
		view = 0;
		total = 0;
		interval = 1;
		int_unit = 0;
		max_pos = 0;
	}
	void ScrollBar::Destroy ()
	{
		//The Destroy function will handle errors itself, so we need not worry about it.
		Window::Destroy ();
	}

	//Always redraw if necessary, since all values have default values.
	void ScrollBar::SetBorders (int new_bord_x, int new_bord_y)
	{
		assert (GetWindow ());

		bord_x = new_bord_x;
		bord_y = new_bord_y;

		Redraw ();
	}
	void ScrollBar::SetScrollInt (int new_interval)
	{
		assert (GetWindow ());

		interval = new_interval;
		scroll_const = static_cast<double>(WHEEL_DELTA) / static_cast<double>(interval);
	}
	void ScrollBar::SetView (int new_view, int new_total)
	{
		RECT wnd_rect;

		assert (new_total >= 0);
		assert (GetWindow ());

		view = new_view;
		total = new_total;
		max_pos = total - view;

		//Check for out of bounds exceptions.
		if (pos < 0)
			pos = 0;
		else if (pos > max_pos)
			pos = max_pos;

		::GetClientRect (GetWindow (), &wnd_rect);
		int_unit = static_cast<double>(wnd_rect.bottom - 2 * bord_y) / static_cast<double>(total);

		Redraw ();
	}
	void ScrollBar::SetColors (COLORREF new_normal_color, COLORREF new_hover_color, COLORREF new_down_color, COLORREF new_bk_color)
	{
		assert (GetWindow ());

		normal_color = new_normal_color;
		hover_color = new_hover_color;
		down_color = new_down_color;
		bk_color = new_bk_color;

		Redraw ();
	}
	
	LRESULT ScrollBar::OnPaint (WPARAM wparam, LPARAM lparam)
	{
		HBRUSH bk_brush = CreateSolidBrush (bk_color), bar_brush, orig_brush;
		HPEN bk_pen = CreatePen (PS_SOLID, 1, RGB (0,0,0)), bar_pen, orig_pen;
		RECT wnd_rect;
		int left, top, right, bottom;
		HDC dc;

		BeginPaint ();
		dc = BeginOffScreenDC ();
		::GetClientRect (GetWindow (), &wnd_rect);
		
		if (state == NORMAL)
		{
			bar_brush = CreateSolidBrush (normal_color);
			bar_pen = CreatePen (PS_SOLID, 1, normal_color);
		}
		else if (state == HOVER)
		{
			bar_brush = CreateSolidBrush (hover_color);
			bar_pen = CreatePen (PS_SOLID, 1, hover_color);
		}
		else if (state == DOWN)
		{
			bar_brush = CreateSolidBrush (down_color);
			bar_pen = CreatePen (PS_SOLID, 1, down_color);
		}

		orig_brush = reinterpret_cast<HBRUSH>(SelectObject (dc, bk_brush));
		orig_pen = reinterpret_cast<HPEN>(SelectObject (dc, bk_pen));
		Rectangle (dc, 0, 0, wnd_rect.right, wnd_rect.bottom);

		//Just replace with orig's at the end.
		SelectObject (dc, bar_brush);
		SelectObject (dc, bar_pen);
			
		//Check if everything is in bounds first. If not, don't draw the bar. Other functions should handle out of bounds.
		if (view <= total && total > 0 && pos <= max_pos)
		{
			left = bord_x;
			top = bord_y + static_cast<int>(static_cast<double>(pos) * int_unit + 0.5);
			right = wnd_rect.right - bord_x;
			bottom = bord_y + static_cast<int>(static_cast<double>(view + pos) * int_unit + 0.5);

			Rectangle (dc, left, top, right, bottom);
		}

		SelectObject (dc, orig_brush);
		SelectObject (dc, orig_pen);
		DeleteObject (bk_brush);
		DeleteObject (bk_pen);
		DeleteObject (bar_brush);
		DeleteObject (bar_pen);

		EndOffScreenDC ();
		EndPaint ();

		return static_cast<LRESULT>(0);
	}
	LRESULT ScrollBar::OnLButtonUp (WPARAM wparam, LPARAM lparam)
	{
		if (GetWindow () == GetCapture ())
			ReleaseCapture ();

		state = NORMAL;
		Redraw ();

		return static_cast<LRESULT>(0);
	}
	LRESULT ScrollBar::OnLButtonDown (WPARAM wparam, LPARAM lparam)
	{
		::SetFocus (GetWindow ());

		if (state == HOVER)
		{
			//Calculate the offset_y: the number of pixels y offsets the top of the bar.
			offset_y = bord_y + GET_Y_LPARAM (lparam) - (bord_y + static_cast<int>(static_cast<double>(pos) * int_unit + 0.5));
			state = DOWN;
			Redraw ();
		}

		return static_cast<LRESULT>(0);
	}
	LRESULT ScrollBar::OnMouseMove (WPARAM wparam, LPARAM lparam)
	{
		int x = GET_X_LPARAM (lparam), y = GET_Y_LPARAM (lparam);
		RECT wnd_rect;
		bool on_bar;

		::GetClientRect (GetWindow (), &wnd_rect);
		on_bar = (x >= bord_x && 
			x <= wnd_rect.right - bord_x && 
			y >= bord_y + static_cast<int>(static_cast<double>(pos) * int_unit + 0.5) && 
			y <= bord_y + static_cast<int>(static_cast<double>(view + pos) * int_unit + 0.5));

		if (state == NORMAL && on_bar)
		{
			state = HOVER;
			Redraw ();

			if (GetWindow () != GetCapture ())
				SetCapture (GetWindow ());
		}
		else if (state == HOVER && !on_bar)
		{
			state = NORMAL;
			Redraw ();

			if (GetWindow () == GetCapture ())
				ReleaseCapture ();
		}
		else if (state == DOWN)
		{
			pos = static_cast<int>(static_cast<double>(y - offset_y - bord_y) / int_unit + 0.5);

			if (pos < 0)
				pos = 0;
			else if (pos > max_pos)
				pos = max_pos;
			
			//When the scroll bar moves, tell the parent window so that it can update whatever its showing.
			::SendMessage (::GetParent (GetWindow ()), WM_SCROLLBARSCROLL, reinterpret_cast<WPARAM>(&pos), NULL);
			Redraw ();
		}

		return static_cast<LRESULT>(0);
	}
	LRESULT ScrollBar::OnMouseWheel (WPARAM wparam, LPARAM lparam)
	{
		RECT wnd_rect;
		POINT cursor;

		//No point in scrolling while holding the bar, or if we have less than we can see.
		if (state != DOWN && total >= view)
		{
			::GetClientRect (GetWindow (), &wnd_rect);
			::GetCursorPos (&cursor);
			::ScreenToClient (this->GetWindow (), &cursor);
			pos -= static_cast<int>(static_cast<double>(GET_WHEEL_DELTA_WPARAM (wparam)) / scroll_const);

			if (pos < 0)
				pos = 0;
			else if (pos > max_pos)
				pos = max_pos;
			
			::SendMessage (::GetParent (GetWindow ()), WM_SCROLLBARSCROLL, reinterpret_cast<WPARAM>(&pos), NULL);
			::SendMessage (GetWindow (), WM_MOUSEMOVE, NULL, MAKELPARAM (static_cast<signed short>(cursor.x), static_cast<signed short>(cursor.y)));

			//Make sure the bar is redrawn if OnMouseMove doesn't do it.
			if ((state == NORMAL && !(cursor.x >= bord_x && 
					cursor.x <= wnd_rect.right - bord_x && 
					cursor.y >= bord_y + static_cast<int>(static_cast<double>(pos) * int_unit + 0.5) && 
					cursor.y <= bord_y + static_cast<int>(static_cast<double>(view + pos) * int_unit + 0.5))) || 
				state == HOVER && (cursor.x >= bord_x && 
					cursor.x <= wnd_rect.right - bord_x && 
					cursor.y >= bord_y + static_cast<int>(static_cast<double>(pos) * int_unit + 0.5) && 
					cursor.y <= bord_y + static_cast<int>(static_cast<double>(view + pos) * int_unit + 0.5)))
				Redraw ();
		}
		
		return static_cast<LRESULT>(0);
	}
	LRESULT ScrollBar::OnEraseBkgnd (WPARAM wparam, LPARAM lparam)
	{
		return static_cast<LRESULT>(1);
	}
	LRESULT ScrollBar::OnSize (WPARAM wparam, LPARAM lparam)
	{
		int_unit = static_cast<double>(HIWORD (lparam) - 2 * bord_y) / static_cast<double>(total);

		return static_cast<LRESULT>(0);
	}
}