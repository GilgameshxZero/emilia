/*
Standard
*/

/*This library is standardized and regulated, for providing shorcuts for winsock-related actions.
Includes full error-checking and error-management functions.
Resource management is mostly dealt-with within the functions - though WSA Cleanup may need to be called at exit.*/

#pragma once

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif

#ifndef _WINSOCKAPI_ //stops windows.h and winsock2.h from interfering in their definitions, sometimes
#define _WINSOCKAPI_
#endif

#include "RainWindow.h"
#include "WindowsLAMInclude.h"

#include <winsock2.h>
#include <ws2tcpip.h>
#include <iphlpapi.h>
#include <stdio.h>
#include <unordered_map>
#include <string>

#pragma comment(lib, "Ws2_32.lib")

namespace Rain
{
	typedef int (*WSARecvPMFunc) (void *);
	typedef void (*WSARecvInitFunc) (void *);
	typedef void (*WSARecvExitFunc) (void *);

	class WSARecvParam
	{
		public:
			WSARecvParam ();
			WSARecvParam (SOCKET *sock, std::string *message, int buflen, void *funcparam, WSARecvPMFunc OnProcessMessage, WSARecvInitFunc OnRecvInit, WSARecvExitFunc OnRecvEnd);

			SOCKET *sock;
			std::string *message;
			int buflen;
			void *funcparam;
			WSARecvPMFunc OnProcessMessage; //return nonzero to terminate recv
			WSARecvInitFunc OnRecvInit;
			WSARecvExitFunc OnRecvEnd;
	};

	int InitWinsock (WSADATA &wsaData);

	//client side functions
	int GetClientAddr (std::string host, std::string port, struct addrinfo **result);
	int CreateClientSocket (struct addrinfo **ptr, SOCKET &ConnectSocket);
	int ConnToServ (struct addrinfo **ptr, SOCKET &ConnectSocket); //never frees ptr; we might need it again

	int QuickClientInit (WSADATA &wsaData, std::string host, std::string port, struct addrinfo **paddr, SOCKET &connect);

	//server side functions
	int GetServAddr (std::string port, struct addrinfo **result);
	int CreateServLSocket (struct addrinfo **ptr, SOCKET &ListenSocket);
	int BindServLSocket (struct addrinfo **ptr, SOCKET &ListenSocket); //frees ptr
	int ListenServSocket (SOCKET &ListenSocket);
	int ServAcceptClient (SOCKET &ClientSocket, SOCKET &ListenSocket);

	int QuickServerInit (WSADATA &wsaData, std::string port, struct addrinfo **paddr, SOCKET &listener);

	//both sides can use this function
	int ShutdownSocketSend (SOCKET &ConnectSocket);

	//uility
	std::string GetClientNumIP (SOCKET &clientsock);

	//send raw text over a socket
	int SendText (SOCKET &sock, const char *cstrtext, long long len);

	int SendHeader (SOCKET &sock, std::unordered_map<std::string, std::string> *headers);

	//calls a function whenever a message is received; 
	DWORD WINAPI RecvThread (LPVOID lpParameter); //don't use this; use CreateRecvThread
	HANDLE CreateRecvThread (
		WSARecvParam *recvparam, //if NULL: returns pointer to RecvParam that must be freed when the thread ends
							  //if not NULL: ignores the the next 6 parameters, and uses this as the param for RecvThread
		SOCKET *connection = NULL, 
		std::string *message = NULL, //where the message is stored each time OnProcessMessage is called
		int buflen = NULL, //the buffer size of the receive function
		void *funcparam = NULL, //additional parameter to pass to the functions OnProcessMessage and OnRecvEnd
		WSARecvPMFunc OnProcessMessage = NULL,
		WSARecvInitFunc OnRecvInit = NULL, //called at the beginning of thread
		WSARecvExitFunc OnRecvEnd = NULL, //called when the other side shuts down send
		DWORD dwCreationFlags = 0, 
		SIZE_T dwStackSize = 0, 
		LPDWORD lpThreadId = NULL, 
		LPSECURITY_ATTRIBUTES lpThreadAttributes = NULL);

	//create a message queue/window which will respond to messages sent to it
	//RainWindow * which is returned must be freed
	RainWindow *CreateSendHandler (std::unordered_map<UINT, RainWindow::MSGFC> *msgm); 
}