/*
Deprecated
*/

/*Current implementation outputs to cerr.
Redirect to file.*/

#pragma once
#include <string>
#include <iostream>

namespace Rain
{
	void ReportError (std::string desc, int code);
}