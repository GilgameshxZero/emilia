#include <propsys.h>
#include <shlwapi.h>
#include <shobjidl.h>
#include <sstream>
#include <string>
#include <Windows.h>
#include <WindowsX.h>
#include "FileEdit.h"
#include "Window.h"

namespace RainCorporation
{
	namespace FileEdit
	{
		const std::string		FILEEDITFONT	= "Verdana";
		const int				DEFAULTHEIGHT	= 40;
		const int				WORDXSHIFT		= 10;
		const int				WORDYSHIFT		= 6;
		const COMDLG_FILTERSPEC	DIALOGTYPES[]	=	{
														{L"All Documents (*.*)",		L"*.*"}
													};

		FileEdit::FileEdit (void)
		{
			this->edit_wnd		= NULL;
			this->parent_wnd	= NULL;
			this->state			= "Normal";
			this->file_path		= "";
			this->cx			= 0;
			this->open			= true;
		}

		void FileEdit::Initialize (HWND parent_wnd, int width, bool open)
		{
			static int identifier; //Use this variable to create unique class names.
			HINSTANCE instance = reinterpret_cast<HINSTANCE>(GetWindowLongPtr (parent_wnd, GWLP_HINSTANCE));
			std::stringstream sstream;
			std::string EditClassName_str;
			LPCSTR EditClassName, EditTitleText;

			sstream << "RainCorporation::FileEdit: " << identifier++;
			EditClassName_str = sstream.str ();
			EditClassName = EditTitleText = EditClassName_str.c_str ();

			//Initialize member variables.
			this->cx = width;
			this->parent_wnd = parent_wnd;
			this->open = open;

			//Create the window.
			this->edit_wnd = RainCorporation::Window::InitializeWindow (FileEditProc, instance, EditClassName, EditTitleText, WS_CHILD, this->cx, DEFAULTHEIGHT, this, this->parent_wnd, reinterpret_cast<HBRUSH>(COLOR_WINDOW + 1), WS_EX_NOPARENTNOTIFY);
			
			//Hide the window.
			ShowWindow (this->edit_wnd, SW_HIDE);

			return;
		}

		void FileEdit::Show (int x, int y)
		{
			this->state = "Normal";
			MoveWindow (this->edit_wnd, x, y, cx, DEFAULTHEIGHT, false);
			ShowWindow (this->edit_wnd, SW_SHOW);
		}
		void FileEdit::Hide ()
		{
			this->state = "Hidden";
			ShowWindow (this->edit_wnd, SW_HIDE);
		}

		void FileEdit::SetPath (std::string new_path)
		{
			file_path = new_path;

			Draw ();
		}
		std::string FileEdit::GetPath ()
		{
			return file_path;
		}

		void FileEdit::Draw ()
		{
			HPEN pen = CreatePen (PS_SOLID, 1, RGB (0,0,0)), orig_pen;
			HDC DCMem, DC = GetDC (this->edit_wnd);
			HBRUSH brush, orig_brush;
			HFONT font, orig_font;
			HBITMAP BMMem, BMOld;
			int max_chars = 0;
			SIZE tsize;
			RECT cRect;

			//Set up an off-screen DC.
			GetClientRect (this->edit_wnd, &cRect);

			DCMem = CreateCompatibleDC (DC);
			BMMem = CreateCompatibleBitmap (DC, cRect.right - cRect.left, cRect.bottom - cRect.top);
			BMOld = reinterpret_cast<HBITMAP>(SelectObject (DCMem, BMMem));

			FillRect (DCMem, &cRect, CreateSolidBrush (RGB (255,255,255)));

			//Edit brush to ensure right background and outline color.
			if (this->state == "Normal")
				brush = CreateSolidBrush (RGB (230,230,230));
			else if (this->state == "Hover")
				brush = CreateSolidBrush (RGB (200,200,200));
			else if (this->state == "Drag")
				brush = CreateSolidBrush (RGB (255,150,150));
			else if (this->state == "Down")
				brush = CreateSolidBrush (RGB (150,150,255));

			font = CreateFont (-MulDiv (12, GetDeviceCaps (DCMem, LOGPIXELSY), 72), 0, 0, 0, 0, false, false, false, 0, 0, 0, 0, 0, FILEEDITFONT.c_str ());

			SetTextColor (DCMem, RGB (0,0,0));
			SetBkMode (DCMem, TRANSPARENT);
			orig_brush = reinterpret_cast<HBRUSH>(SelectObject (DCMem, brush));
			orig_pen = reinterpret_cast<HPEN>(SelectObject (DCMem, pen));
			orig_font = reinterpret_cast<HFONT>(SelectObject (DCMem, font));

			Rectangle (DCMem, 0, 0, cx, DEFAULTHEIGHT);

			//Use a loop here to calculate the number of letters we can fit in the Edit. The rest we will put as "...".
			for (max_chars = 3;max_chars <= static_cast<int>(file_path.length () + 3);max_chars++)
			{
				//We calculate the size of the text with only the first 'a' characters.
				GetTextExtentPoint32 (DCMem, (file_path.substr (0, max_chars - 3) + "...").c_str (), max_chars, &tsize);

				//If we can't fit this many characters into the Edit, then we quit and fit 4 less than that, with the last 3 being "...".
				if (tsize.cx > static_cast<int>(this->cx - WORDXSHIFT * 2))
				{
					max_chars--;
					break;
				}
			}

			//Print text at coordinates.
			if (static_cast<int>(file_path.length () + 3) > max_chars) //If we need to abbreviate the file path.
				TextOut (DCMem, WORDXSHIFT, WORDYSHIFT, (file_path.substr (0, max_chars - 3) + "...").c_str (), max_chars);
			else //We can fit the file path in the FileEdit.
				TextOut (DCMem, WORDXSHIFT, WORDYSHIFT, file_path.c_str (), static_cast<int>(file_path.length ()));

			//Off-screen DC.
			BitBlt (DC, cRect.left, cRect.top, cRect.right - cRect.left, cRect.bottom - cRect.top, DCMem, 0, 0, SRCCOPY);

			SelectObject (DCMem, orig_brush);
			SelectObject (DCMem, orig_pen);
			SelectObject (DCMem, orig_font);
			SelectObject (DCMem, BMOld);
			DeleteObject (BMMem);
			DeleteDC (DCMem);
			DeleteObject (brush);
			DeleteObject (pen);
			DeleteObject (font);
			ReleaseDC (this->edit_wnd, DC);

			return;
		}

		void FileEdit::CheckMove (int x, int y)
		{
			if (this->state == "Normal")
			{
				this->state = "Hover";
				Draw ();

				if (this->edit_wnd != GetCapture ())
					SetCapture (this->edit_wnd);
			}
			else if (this->state == "Hover" && !(x >= 0 && x <= cx && y >= 0 && y <= DEFAULTHEIGHT))
			{
				this->state = "Normal";
				Draw ();

				if (this->edit_wnd == GetCapture ())
					ReleaseCapture ();
			}
			else if (this->state == "Drag" && x >= 0 && x <= cx && y >= 0 && y <= DEFAULTHEIGHT)
			{
				this->state = "Down";
				Draw ();
			}
			else if (this->state == "Down" && !(x >= 0 && x <= cx && y >= 0 && y <= DEFAULTHEIGHT))
			{
				this->state = "Drag";
				Draw ();
			}
		}
		void FileEdit::CheckUp (int x, int y)
		{
			IFileDialog *file_dialog;
			IFileDialogEvents *file_dialog_events = NULL;
			HRESULT rtrn;
			DWORD dwCookie, dwFlags;
			IShellItem *si_result, *si_deffolder;
			PWSTR file_path = NULL;
			LPCWSTR default_path;
			std::wstringstream ss;
			std::wstring ws;

			if (this->edit_wnd == GetCapture ())
				ReleaseCapture ();

			if (this->state == "Down" && x >= 0 && x <= cx && y >= 0 && y <= DEFAULTHEIGHT)
			{
				//Initialize and show file dialog.
				if (this->open == true)
					rtrn = CoCreateInstance(CLSID_FileOpenDialog, NULL, CLSCTX_INPROC_SERVER, IID_PPV_ARGS (&file_dialog));
				else
					rtrn = CoCreateInstance(CLSID_FileSaveDialog, NULL, CLSCTX_INPROC_SERVER, IID_PPV_ARGS (&file_dialog));

				if (SUCCEEDED (rtrn))
				{
					rtrn = CDialogEventHandler_CreateInstance (IID_PPV_ARGS (&file_dialog_events));

					if (SUCCEEDED (rtrn))
					{
						rtrn = file_dialog->Advise (file_dialog_events, &dwCookie);

						if (SUCCEEDED (rtrn))
						{
							rtrn = file_dialog->GetOptions (&dwFlags);

							if (SUCCEEDED (rtrn))
							{
								rtrn = file_dialog->SetOptions (dwFlags | FOS_FORCEFILESYSTEM);

								if (SUCCEEDED (rtrn))
								{
									//Adjust title based on what type of dialog this is.
									if (this->open == true)
										rtrn = file_dialog->SetTitle (L"Open File...");
									else
										rtrn = file_dialog->SetTitle (L"Save As...");

									if (SUCCEEDED (rtrn))
									{
										rtrn = file_dialog->SetFileTypes (ARRAYSIZE (DIALOGTYPES), DIALOGTYPES);

										if (SUCCEEDED (rtrn))
										{
											//Set the default file type to "All Files".
											rtrn = file_dialog->SetFileTypeIndex (1);

											if (SUCCEEDED (rtrn))
											{
												//Set a default folder if there is one. First set default_path to the current file_path. The first few lines of code are from http://stackoverflow.com/questions/27220/how-to-convert-stdstring-to-lpcwstr-in-c-unicode.
												if (this->file_path != "")
												{
													int len, s_len = (int)this->file_path.length () + 1;
													len = MultiByteToWideChar (CP_ACP, 0, this->file_path.c_str (), s_len, 0, 0); 
													wchar_t* buffer = new wchar_t[len];
													MultiByteToWideChar (CP_ACP, 0, this->file_path.c_str (), s_len, buffer, len);
													std::wstring wide_string (buffer);
													delete[] buffer;

													default_path = wide_string.c_str ();
													rtrn = SHCreateItemFromParsingName (default_path, NULL, IID_PPV_ARGS (&si_deffolder));
												}

												if (SUCCEEDED (rtrn))
												{
													if (this->file_path != "")
														rtrn = file_dialog->SetFolder (si_deffolder);

													if (SUCCEEDED (rtrn))
													{
														rtrn = file_dialog->Show (NULL);

														if (SUCCEEDED (rtrn))
														{
															rtrn = file_dialog->GetResult (&si_result);

															if (SUCCEEDED (rtrn))
															{
																rtrn = si_result->GetDisplayName (SIGDN_FILESYSPATH, &file_path);

																if (SUCCEEDED (rtrn))
																{
																	//Deal with file_path. Disregard wide characters for now. Some of the methods below are very unsafe, and can be further improved on in further expansions.
																	ss << file_path;
																	ws = ss.str ();
																	this->file_path = std::string (ws.begin (), ws.end ());

																	CoTaskMemFree (file_path);
																}

																si_result->Release ();
															}
														}
													}
												}
											}
										}
									}
								}
							}

							file_dialog->Unadvise (dwCookie);
						}

						file_dialog_events->Release ();
					}

					file_dialog->Release ();
				}
			}
			
			this->state = "Normal";
			Draw ();
		}
		void FileEdit::CheckDown (int x, int y)
		{
			SetFocus (this->edit_wnd);
			this->state = "Down";
			Draw ();
		}

		//The following are some functions needed for creating the dialog. This is code from Microsoft, best not to mess with it. The first two functions can be empty, but expanded on later.
		HRESULT FileEdit::CDialogEventHandler::OnTypeChange (IFileDialog *file_dialog)
		{
			return S_OK;
		}
		HRESULT FileEdit::CDialogEventHandler::OnItemSelected (IFileDialogCustomize *file_dialog_custom, DWORD dw_control, DWORD dw_item)
		{
			return S_OK;
		}
		HRESULT FileEdit::CDialogEventHandler_CreateInstance (REFIID riid, void **ppv)
		{
			HRESULT hr;
			CDialogEventHandler *pDialogEventHandler = new (std::nothrow) CDialogEventHandler ();

			*ppv = NULL;
			hr = pDialogEventHandler ? S_OK : E_OUTOFMEMORY;

			if (SUCCEEDED (hr))
			{
				hr = pDialogEventHandler->QueryInterface (riid, ppv);
				pDialogEventHandler->Release ();
			}

			return hr;
		}

		LRESULT CALLBACK FileEditProc (HWND edit_wnd, UINT msg, WPARAM wparam, LPARAM lparam)
		{
			switch(msg)
			{
				case WM_MOUSEMOVE:
				{
					FileEdit *WndClass = reinterpret_cast<FileEdit *>(GetWindowLongPtr (edit_wnd, GWLP_USERDATA));
					WndClass->CheckMove (GET_X_LPARAM (lparam), GET_Y_LPARAM (lparam));

					break;
				}

				case WM_LBUTTONDOWN:
				{
					FileEdit *WndClass = reinterpret_cast<FileEdit *>(GetWindowLongPtr (edit_wnd, GWLP_USERDATA));
					WndClass->CheckDown (GET_X_LPARAM (lparam), GET_Y_LPARAM (lparam));

					break;
				}

				case WM_LBUTTONUP:
				{
					FileEdit *WndClass = reinterpret_cast<FileEdit *>(GetWindowLongPtr (edit_wnd, GWLP_USERDATA));
					WndClass->CheckUp (GET_X_LPARAM (lparam), GET_Y_LPARAM (lparam));

					break;
				}

				case WM_PAINT:
				{
					PAINTSTRUCT ps;
					FileEdit *WndClass = reinterpret_cast<FileEdit *>(GetWindowLongPtr (edit_wnd, GWLP_USERDATA));

					BeginPaint (edit_wnd, &ps);
					WndClass->Draw ();
					EndPaint (edit_wnd, &ps);

					break;
				}

				default:
					return DefWindowProc (edit_wnd, msg, wparam, lparam);
			}

			return 0;
		}
	}
}