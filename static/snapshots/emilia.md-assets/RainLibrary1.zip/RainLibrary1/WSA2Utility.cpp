#include "WSA2Utility.h"

namespace Rain
{
	WSARecvParam::WSARecvParam ()
	{
	}

	WSARecvParam::WSARecvParam (SOCKET *sock, std::string *message, int buflen, void *funcparam, WSARecvPMFunc OnProcessMessage, WSARecvInitFunc OnRecvInit, WSARecvExitFunc OnRecvEnd)
	{
		this->sock = sock;
		this->message = message;
		this->buflen = buflen;
		this->funcparam = funcparam;
		this->OnProcessMessage = OnProcessMessage;
		this->OnRecvInit = OnRecvInit;
		this->OnRecvEnd = OnRecvEnd;
	}

	int InitWinsock (WSADATA &wsaData)
	{
		return WSAStartup (MAKEWORD (2, 2), &wsaData);
	}

	int GetClientAddr (std::string host, std::string port, struct addrinfo **result)
	{
		struct addrinfo hints;

		ZeroMemory (&hints, sizeof (hints));
		hints.ai_family = AF_UNSPEC;
		hints.ai_socktype = SOCK_STREAM;
		hints.ai_protocol = IPPROTO_TCP;

		int ret = getaddrinfo (host.c_str (), port.c_str (), &hints, result);
		if (ret != 0)
			WSACleanup ();
		return ret;
	}

	int CreateClientSocket (struct addrinfo **ptr, SOCKET &ConnectSocket)
	{
		ConnectSocket = INVALID_SOCKET;

		ConnectSocket = socket ((*ptr)->ai_family, (*ptr)->ai_socktype,
			(*ptr)->ai_protocol);

		if (ConnectSocket == INVALID_SOCKET)
		{
			int ret = WSAGetLastError ();
			freeaddrinfo (*ptr);
			WSACleanup ();
			return ret;
		}
		return 0;
	}

	int ConnToServ (struct addrinfo **ptr, SOCKET &ConnectSocket)
	{
		struct addrinfo *curaddr = (*ptr);
		int ret;

		while (true)
		{
			ret = connect (ConnectSocket, curaddr->ai_addr, (int)curaddr->ai_addrlen);
			if (ret == SOCKET_ERROR)
				ret = WSAGetLastError ();
			else
				break;

			if (curaddr->ai_next == NULL)
				break;

			curaddr = curaddr->ai_next;
		}

		return ret;
	}

	int ShutdownSocketSend (SOCKET &ConnectSocket)
	{
		if (shutdown (ConnectSocket, SD_SEND) == SOCKET_ERROR)
		{
			int ret = WSAGetLastError ();
			closesocket (ConnectSocket);
			WSACleanup ();
			return ret;
		}

		return 0;
	}

	int GetServAddr (std::string port, struct addrinfo **result)
	{
		struct addrinfo hints;

		ZeroMemory (&hints, sizeof (hints));
		hints.ai_family = AF_INET;
		hints.ai_socktype = SOCK_STREAM;
		hints.ai_protocol = IPPROTO_TCP;
		hints.ai_flags = AI_PASSIVE;

		int ret = getaddrinfo (NULL, port.c_str (), &hints, result);
		if (ret != 0)
			WSACleanup ();
		return ret;
	}

	int CreateServLSocket (struct addrinfo **ptr, SOCKET &ListenSocket)
	{
		ListenSocket = socket ((*ptr)->ai_family, (*ptr)->ai_socktype, (*ptr)->ai_protocol);

		if (ListenSocket == INVALID_SOCKET)
		{
			int ret = WSAGetLastError ();
			freeaddrinfo (*ptr);
			WSACleanup ();
			return ret;
		}
		return 0;
	}

	int BindServLSocket (struct addrinfo **ptr, SOCKET &ListenSocket)
	{
		if (bind (ListenSocket, (*ptr)->ai_addr, (int)(*ptr)->ai_addrlen) == SOCKET_ERROR)
		{
			int ret = WSAGetLastError ();
			freeaddrinfo (*ptr);
			closesocket (ListenSocket);
			WSACleanup ();
			return ret;
		}

		freeaddrinfo (*ptr);
		return 0;
	}

	int ListenServSocket (SOCKET &ListenSocket)
	{
		if (listen (ListenSocket, SOMAXCONN) == SOCKET_ERROR)
		{
			int ret = WSAGetLastError ();
			closesocket (ListenSocket);
			WSACleanup ();
			return ret;
		}
		return 0;
	}

	int ServAcceptClient (SOCKET &ClientSocket, SOCKET &ListenSocket)
	{
		ClientSocket = INVALID_SOCKET;

		ClientSocket = accept (ListenSocket, NULL, NULL);
		if (ClientSocket == INVALID_SOCKET)
		{
			int ret = WSAGetLastError ();
			closesocket (ListenSocket);
			WSACleanup ();
			return ret;
		}
		return 0;
	}

	std::string GetClientNumIP (SOCKET &clientsock)
	{
		static struct sockaddr clname;
		static int clnamesize;
		static TCHAR clhname[32];

		clnamesize = sizeof (clname);
		getpeername (clientsock, &clname, &clnamesize);
		getnameinfo (&clname, clnamesize, clhname, 32, NULL, NULL, NI_NUMERICHOST);

		return std::string (clhname);
	}

	DWORD WINAPI RecvThread (LPVOID lpParameter) {
		WSARecvParam *recvparam = reinterpret_cast<WSARecvParam *>(lpParameter);
		char *buffer = new char[recvparam->buflen];
		int ret;

		if (recvparam->OnRecvInit != NULL)
			recvparam->OnRecvInit (recvparam->funcparam);

		//receive data until the server closes the connection
		do
		{
			ret = recv (*recvparam->sock, buffer, recvparam->buflen, 0);
			if (ret > 0) //received ret bytes
			{
				*recvparam->message = std::string (buffer, ret);
				if (recvparam->OnProcessMessage != NULL)
					if (recvparam->OnProcessMessage (recvparam->funcparam))
						break;
			}
			else if (ret == 0)
				break; //connection closed
			else //failure
			{
				ret = WSAGetLastError ();
				break;
			}
		} while (ret > 0);

		delete[] buffer;
		if (recvparam->OnRecvEnd != NULL)
			recvparam->OnRecvEnd (recvparam->funcparam);

		return ret;
	}

	int SendText (SOCKET &sock, const char *cstrtext, long long len)
	{
		long long sent = 0;
		int ret;

		while (sent < len)
		{
			ret = send (sock, cstrtext + sent, static_cast<int>(len - sent), 0);
			if (ret == SOCKET_ERROR)
			{
				ret = WSAGetLastError ();
				return ret;
			}

			sent += ret;
		}

		return 0;
	}

	int SendHeader (SOCKET &sock, std::unordered_map<std::string, std::string> *headers)
	{
		std::string message;
		for (std::unordered_map<std::string, std::string>::iterator it = headers->begin ();it != headers->end ();it++)
			message += it->first + ": " + it->second + "\n";
		message += "\n";
		return Rain::SendText (sock, message.c_str (), message.length ());
	}

	int QuickClientInit (WSADATA &wsaData, std::string host, std::string port, struct addrinfo **paddr, SOCKET &connect)
	{
		int error;
		error = Rain::InitWinsock (wsaData);
		if (error) return error;
		error = Rain::GetClientAddr (host, port, paddr);
		if (error) return error;
		error = Rain::CreateClientSocket (paddr, connect);
		if (error) return error;
		return 0;
	}

	int QuickServerInit (WSADATA &wsaData, std::string port, struct addrinfo **paddr, SOCKET &listener)
	{
		int error;
		error = Rain::InitWinsock (wsaData);
		if (error) return error;
		error = Rain::GetServAddr (port, paddr);
		if (error) return error;
		error = Rain::CreateServLSocket (paddr, listener);
		if (error) return error;
		error = Rain::BindServLSocket (paddr, listener);
		if (error) return error;
		return 0;
	}

	HANDLE CreateRecvThread (
		WSARecvParam *recvparam, //if NULL: returns pointer to RecvParam that must be freed when the thread ends
							  //if not NULL: ignores the the next 6 parameters, and uses this as the param for RecvThread
		SOCKET *connection,
		std::string *message, //where the message is stored each time OnProcessMessage is called
		int buflen, //the buffer size of the receive function
		void *funcparam, //additional parameter to pass to the functions OnProcessMessage and OnRecvEnd
		WSARecvPMFunc OnProcessMessage,
		WSARecvInitFunc OnRecvInit, //called when thread starts
		WSARecvExitFunc OnRecvEnd, //called when the other side shuts down send
		DWORD dwCreationFlags,
		SIZE_T dwStackSize,
		LPDWORD lpThreadId,
		LPSECURITY_ATTRIBUTES lpThreadAttributes)
	{
		if (recvparam == NULL)
			recvparam = new WSARecvParam (connection, message, buflen, funcparam, OnProcessMessage, OnRecvInit, OnRecvEnd);

		return CreateThread (lpThreadAttributes, dwStackSize, RecvThread, reinterpret_cast<LPVOID>(recvparam), dwCreationFlags, lpThreadId);
	}

	RainWindow *CreateSendHandler (std::unordered_map<UINT, RainWindow::MSGFC> *msgm)
	{
		RainWindow *rw = new RainWindow ();
		rw->Create (msgm, NULL, NULL, 0, 0, GetModuleHandle (NULL), NULL, NULL, NULL, "", NULL, NULL, "", WS_POPUP, 0, 0, 0, 0, NULL, NULL, RainWindow::NULLCLASSNAME);

		return rw;
	}
}