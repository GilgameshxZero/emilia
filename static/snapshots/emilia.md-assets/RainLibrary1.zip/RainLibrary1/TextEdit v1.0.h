#ifndef RAINCORPORATION_TEXTEDIT
#define RAINCORPORATION_TEXTEDIT

#include <Windows.h>
#include <string>
#include "Window.h"

/*
This class encapsulates a textedit window for their use in RainCorporation projects. Perhaps, one day, we will be able to re-invent the wheel.
*/

#define	WM_RAINCORPTEXTEDITCHANGE	0x0502

namespace RainCorporation
{
	namespace TextEdit
	{
		extern const int	BORDERXDIST;
		extern const int	BORDERYDIST;

		class TextEdit
		{
			public:
				TextEdit (void);
				void Initialize (HWND parent_wnd, int cx, int cy, std::string style = "Left", int fontsize = 12, std::string font = "Verdana");

				std::string GetText ();
				bool SetText (std::string new_string);
				void Show (int x, int y);
				void Hide ();

			private:
				bool Draw ();

				void CheckMove (int x, int y);
				void CheckUp (int x, int y);
				void CheckDown (int x, int y);
				void CheckDeactivate ();

				std::string text, state;
				HWND edit_wnd, parent_wnd, text_edit;
				HFONT font;
				int cx, cy, font_size;

			//Friend the message handler so that it can access the Check functions.
			friend LRESULT CALLBACK ButtonProc (HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);
		};
	}
}

#endif