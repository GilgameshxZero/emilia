#include "ErrorReport.h"

namespace Rain
{
	void ReportError (std::string desc, int code)
	{
		std::cerr << desc << "\nError code: " << code << std::endl;
	}
}