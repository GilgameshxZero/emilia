/*
Standard
*/

//Use this include for GDI+ programs.

#pragma once

#include "WindowsLAMInclude.h"

#include <objidl.h>
#include <gdiplus.h>

#pragma comment (lib,"Gdiplus.lib")