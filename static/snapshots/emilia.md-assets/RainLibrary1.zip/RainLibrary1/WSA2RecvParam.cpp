#include <WSA2RecvParam.h>

namespace Rain
{
	WSARecvParam::WSARecvParam ()
	{
	}

	WSARecvParam::WSARecvParam (SOCKET *sock, std::string *message, int buflen, void *funcparam, WSARecvPMFunc OnProcessMessage, WSARecvInitFunc OnRecvInit, WSARecvExitFunc OnRecvEnd)
	{
		this->sock = sock;
		this->message = message;
		this->buflen = buflen;
		this->funcparam = funcparam;
		this->OnProcessMessage = OnProcessMessage;
		this->OnRecvInit = OnRecvInit;
		this->OnRecvEnd = OnRecvEnd;
	}
}