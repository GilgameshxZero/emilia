#include "ClientSRH.h"

namespace EBC
{
	DWORD WINAPI SendThread (LPVOID lpParameter)
	{
		ExtMessParam *emp = reinterpret_cast<ExtMessParam *>(lpParameter);
		int ret;

		//implement as window w/ message queue
		MSG msg;
		WNDCLASSEX wcex;
		HINSTANCE hinst = GetModuleHandle (NULL);
		std::string classname, titletext;

		classname = titletext = "SendThreadWnd";

		{//register and create host window
			wcex.cbSize = sizeof (WNDCLASSEX);
			wcex.style = NULL;
			wcex.lpfnWndProc = SendWndProc;
			wcex.cbClsExtra = 0;
			wcex.cbWndExtra = 0;
			wcex.hInstance = hinst;
			wcex.hIcon = NULL;
			wcex.hCursor = LoadCursor (NULL, IDC_ARROW);
			wcex.hbrBackground = NULL;
			wcex.lpszMenuName = NULL;
			wcex.lpszClassName = classname.c_str ();
			wcex.hIconSm = NULL;

			if (!RegisterClassEx (&wcex)) {
				ret = GetLastError ();
				Rain::ReportError ("Could not register " + classname + ".", ret);
				return ret;
			}

			emp->sendwnd = CreateWindowEx (WS_EX_TOPMOST, classname.c_str (), titletext.c_str (), WS_POPUP, 0, 0, 0, 0, NULL, NULL, hinst, NULL);

			if (emp->sendwnd == NULL) {
				ret = GetLastError ();
				Rain::ReportError ("Could not create " + classname + ".", ret);
				return ret;
			}

			UpdateWindow (emp->sendwnd);
			ShowWindow (emp->sendwnd, SW_HIDE);
		}

		//message loop
		while (GetMessage (&msg, NULL, 0, 0) > 0)
		{
			TranslateMessage (&msg);
			DispatchMessage (&msg);
		}

		return static_cast<int>(msg.wParam);
	}

	LRESULT CALLBACK SendWndProc (HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam)
	{
		switch (msg)
		{
			case WM_CLOSE:
			{
				PostQuitMessage (0);
				return 0;
			}

			default:
				break;
		}

		return DefWindowProc (hwnd, msg, wparam, lparam);
	}

	void ProcessMessage (void *funcparam)
	{
		ExtMessParam *emp = reinterpret_cast<ExtMessParam *>(funcparam);
		int ret = 0;

		std::cout << emp->recvqueue->front ();

		if (emp->recvqueue->front () == emp->exittext)
		{
			//send exittext to other side
			ret = Rain::SendTextBuf (emp->sock, emp->exittext);
			if (ret) return;
		}

		emp->recvqueue->pop ();
	}

	void OnRecvEnd (void *funcparam)
	{
		ExtMessParam *emp = reinterpret_cast<ExtMessParam *>(funcparam);

		SendMessage (emp->sendwnd, WM_CLOSE, 0, 0);
	}
}