#ifndef RAIN_SCROLLBAR
#define RAIN_SCROLLBAR

#include <string>
#include <Windows.h>
#include "Window.h"

#define	WM_SCROLLBARSCROLL	WM_APP + 1

namespace Rain
{
	class ScrollBar : public Window
	{
		public:
			ScrollBar ();
			~ScrollBar ();

			void	Initialize	(HWND parent);
			void	Destroy		();

			//Can only be used after initializing (use ASSERT). These functions are not required, but SetView should be vital in any legitimate use of ScrollBar.
			void	SetBorders		(int new_bord_x, int new_bord_y);
			void	SetScrollInt	(int new_interval);
			void	SetView			(int new_view, int new_total);
			void	SetColors		(COLORREF new_normal_color, COLORREF new_hover_color, COLORREF new_down_color, COLORREF new_bk_color);

		private:
			//No ASSERT needed, already protected by Rain::Window.
			LRESULT	OnPaint			(WPARAM wparam, LPARAM lparam);
			LRESULT	OnLButtonUp		(WPARAM wparam, LPARAM lparam);
			LRESULT	OnLButtonDown	(WPARAM wparam, LPARAM lparam);
			LRESULT	OnMouseMove		(WPARAM wparam, LPARAM lparam);
			LRESULT	OnMouseWheel	(WPARAM wparam, LPARAM lparam);
			LRESULT	OnEraseBkgnd	(WPARAM wparam, LPARAM lparam);
			LRESULT	OnSize			(WPARAM wparam, LPARAM lparam);

			//Leave GetWindow for potential issues, and the parent functions are obvious.
			Window::SetUserData;
			Window::SetLargeIcon;
			Window::SetSmallIcon;
			Window::SetExStyle;
			Window::SetStyle;
			Window::SetTitleText;
			//Window::SetParent;

			Window::BeginOffScreenDC;
			Window::EndOffScreenDC;
			Window::BeginPaint;
			Window::EndPaint;

			Window::GetUserData;
			//Window::GetParent;

			Window::RedefineMessage;
			Window::ClearMessages;

			//Window::GetWindow;

			const int		NORMAL;
			const int		HOVER;
			const int		DOWN;

			COLORREF normal_color, hover_color, down_color, bk_color;
			int state, 
				bord_x, bord_y, 
				view, total, interval, pos, max_pos, offset_y;
			double int_unit, scroll_const;
	};
}

#endif