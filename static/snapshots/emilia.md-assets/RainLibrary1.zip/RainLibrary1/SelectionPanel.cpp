#include <cassert>
#include <string>
#include <Windows.h>
#include <windowsx.h>
#include "ScrollBar.h"
#include "SelectionPanel.h"
#include "Window.h"

namespace Rain
{
	SelectionPanel::SelectionPanel () : NORMAL (0), HOVER (1), DOWN (2), XSHIFT (10)
	{
	}
	SelectionPanel::~SelectionPanel ()
	{
	}

	void SelectionPanel::Initialize (HWND parent, bool en_multi, bool en_icons)
	{
		Window::Initialize (CS_HREDRAW | CS_VREDRAW);
		SetStyle (WS_CHILD | WS_CLIPCHILDREN);
		SetParent (parent);
		
		RedefineMessage (WM_ERASEBKGND, static_cast<LRESULT (Rain::Window::*) (WPARAM, LPARAM)>(&SelectionPanel::OnEraseBkgnd));
		RedefineMessage (WM_LBUTTONDOWN, static_cast<LRESULT (Rain::Window::*) (WPARAM, LPARAM)>(&SelectionPanel::OnLButtonDown));
		RedefineMessage (WM_LBUTTONUP, static_cast<LRESULT (Rain::Window::*) (WPARAM, LPARAM)>(&SelectionPanel::OnLButtonUp));
		RedefineMessage (WM_MOUSEMOVE, static_cast<LRESULT (Rain::Window::*) (WPARAM, LPARAM)>(&SelectionPanel::OnMouseMove));
		RedefineMessage (WM_MOUSEWHEEL, static_cast<LRESULT (Rain::Window::*) (WPARAM, LPARAM)>(&SelectionPanel::OnMouseWheel));
		RedefineMessage (WM_PAINT, static_cast<LRESULT (Rain::Window::*) (WPARAM, LPARAM)>(&SelectionPanel::OnPaint));
		RedefineMessage (WM_SCROLLBARSCROLL, static_cast<LRESULT (Rain::Window::*) (WPARAM, LPARAM)>(&SelectionPanel::OnScrollBarScroll));
		RedefineMessage (WM_SIZE, static_cast<LRESULT (Rain::Window::*) (WPARAM, LPARAM)>(&SelectionPanel::OnSize));

		//Initialize scroll bar.
		scroll.Initialize (GetWindow ());
		scroll.SetView (0, 0);
		scroll.Resize (30, 0); //Give the scrollbar some default width.
		scroll.Show ();

		normal_color = RGB (40,40,40);
		hover_color = RGB (50,50,50);
		down_color = RGB (50,50,90);
		bk_color = RGB (20,20,20);
		this->en_multi = en_multi;
		this->en_icons = en_icons;
		font = "Courier New";
		contents.clear ();
		focus_panel = -1;
		states.clear ();
		icons.clear ();
		font_size = 12;
		icons.clear ();
		scroll_pos = 0;
		pheight = 0;
		view = 5;
	}
	void SelectionPanel::Destroy ()
	{
		scroll.Destroy ();
		Window::Destroy ();
	}

	//Redraw the window when these are called.
	void SelectionPanel::SetContents (std::vector<std::string> new_contents)
	{
		assert (GetWindow ());

		contents = new_contents;

		//We have as many panels as the least size of either the icons vector or the contents vector, if en_icons is true.
		if (en_icons)
		{
			if (icons.size () > contents.size ())
				states.resize (contents.size ());
			else
				states.resize (icons.size ());
		}
		else
			states.resize (contents.size ());

		//Check out of bounds.
		if (scroll_pos + view > static_cast<int>(states.size ()))
			scroll_pos = states.size () - view;
		if (scroll_pos < 0)
			scroll_pos = 0;
		
		scroll.SetView (view, states.size ());

		Redraw ();
	}
	void SelectionPanel::SetIcons (std::vector<LPCTSTR> new_icons)
	{
		assert (GetWindow ());
		assert (en_icons);
		
		icons = new_icons;

		//We have as many panels as the least size of either the icons vector or the contents vector, if en_icons is true.
		if (en_icons)
		{
			if (icons.size () > contents.size ())
				states.resize (contents.size ());
			else
				states.resize (icons.size ());
		}
		else
			states.resize (contents.size ());

		//Check out of bounds.
		if (scroll_pos + view > static_cast<int>(states.size ()))
			scroll_pos = states.size () - view;
		if (scroll_pos < 0)
			scroll_pos = 0;
		
		scroll.SetView (view, states.size ());

		Redraw ();
	}
	void SelectionPanel::SetScrollInterval (int new_interval)
	{
		assert (GetWindow ());

		scroll.SetScrollInt (new_interval);
	}
	void SelectionPanel::SetScrollWidth (int new_width)
	{
		RECT wnd_rect, scroll_wnd;
		
		assert (GetWindow ());

		GetClientRect (scroll.GetWindow (), &scroll_wnd);
		GetClientRect (GetWindow (), &wnd_rect);
		scroll.Resize (new_width, scroll_wnd.bottom, false);
		scroll.Move (wnd_rect.right - new_width, 0, true);
		
		Redraw ();
	}
	void SelectionPanel::SetView (int new_view)
	{
		RECT wnd_rect;
		
		assert (GetWindow ());

		GetClientRect (GetWindow (), &wnd_rect);
		view = new_view;
		pheight = static_cast<double>(wnd_rect.bottom) / static_cast<double>(view);
		scroll.SetView (view, states.size ());
		
		Redraw ();
	}
	void SelectionPanel::SetColors (COLORREF new_normal_color, COLORREF new_hover_color, COLORREF new_down_color, COLORREF new_bk_color)
	{
		assert (GetWindow ());

		normal_color = new_normal_color;
		hover_color = new_hover_color;
		down_color = new_down_color;
		bk_color = new_bk_color;
		
		Redraw ();
	}
	void SelectionPanel::SetFont (std::string new_font)
	{
		assert (GetWindow ());

		font = new_font;

		Redraw ();
	}
	void SelectionPanel::SetFontSize (int new_size)
	{
		assert (GetWindow ());

		font_size = new_size;

		Redraw ();
	}

	std::vector<int> SelectionPanel::GetSelection ()
	{
		std::vector<int> rtrn;

		assert (GetWindow ());

		//Loop through the states vector, and find states as DOWN.
		for (int a = 0;a < static_cast<int>(states.size ());a++)
		{
			if (states[a] == DOWN)
				rtrn.push_back (a);
		}

		return rtrn;
	}
	
	LRESULT SelectionPanel::OnEraseBkgnd (WPARAM wparam, LPARAM lparam)
	{
		return static_cast<LRESULT>(1);
	}
	LRESULT SelectionPanel::OnLButtonDown (WPARAM wparam, LPARAM lparam)
	{
		int panel;

		SetFocus (GetWindow ());

		//Find the panel we are on, and change its state to DOWN. If en_multi is false, change all other DOWN panels to NORMAL. If en_multi is true, but neither CTRL of SHIFT is down, do the same. If en_multi is true and CTRL is down, do not modify the other DOWN panels, but if this panel was down before, then make it HOVER. If en_multi is true, and SHIFT is down or both SHIFT and CTRL are down, then change all the states from the panel we are on to the focus_panel to DOWN. If focus_panel is -1, then do not change any other panels.
		panel = static_cast<int>(static_cast<double>(GET_Y_LPARAM (lparam)) / pheight) + scroll_pos;

		//Make sure we aren't clicking on empty space.
		if (panel < static_cast<int>(states.size ()))
		{
			if (!en_multi)
			{
				for (int a = 0;a < static_cast<int>(states.size ());a++)
					if (states[a] == DOWN)
						states[a] = NORMAL;

				states[panel] = DOWN;
			}
			else //Enable multiselect.
			{
				if (((unsigned short)(GetKeyState (VK_SHIFT))) >> 15 == 1) //Shift key down.
				{
					//We must have a previously focused panel.
					if (focus_panel != -1)
					{
						if (focus_panel <= panel)
							for (int a = focus_panel;a <= panel;a++)
								states[a] = DOWN;
						else if (focus_panel > panel)
							for (int a = panel;a <= focus_panel;a++)
								states[a] = DOWN;
					}
				}
				else if (((unsigned short)(GetKeyState (VK_CONTROL))) >> 15 == 1) //Control key down.
				{
					if (states[panel] == DOWN)
						states[panel] = HOVER;
					else
						states[panel] = DOWN;
				}
				else //The same as if en_multi was false.
				{
					for (int a = 0;a < static_cast<int>(states.size ());a++)
						if (states[a] == DOWN)
							states[a] = NORMAL;

					states[panel] = DOWN;
				}
			}

			Redraw ();
			
			//Update the focused panel.
			focus_panel = panel;
		}

		return static_cast<LRESULT>(0);
	}
	LRESULT SelectionPanel::OnLButtonUp (WPARAM wparam, LPARAM lparam)
	{
		return static_cast<LRESULT>(0);
	}
	LRESULT SelectionPanel::OnMouseMove (WPARAM wparam, LPARAM lparam)
	{
		int panel, x = GET_X_LPARAM (lparam), y = GET_Y_LPARAM (lparam);
		RECT wnd_rect, scroll_wnd;
		bool redraw = true;

		GetClientRect (GetWindow (), &wnd_rect);
		GetClientRect (scroll.GetWindow (), &scroll_wnd);
		
		//Not actually on a panel. Reset all hover panels, release the mouse, and redraw.
		if (!(x >= 0 && x <= wnd_rect.right - scroll_wnd.right && y >= 0 && y <= static_cast<int>(static_cast<double>(contents.size ()) * pheight + 0.5)))
		{
			for (int a = 0;a < static_cast<int>(states.size ());a++)
			{
				if (states[a] == HOVER)
					states[a] = NORMAL;
			}

			if (GetWindow () == GetCapture ())
				ReleaseCapture ();

			Redraw ();
		}
		else //Not on the scrollbar.
		{
			//Determine the panel we are on.
			panel = static_cast<int>(static_cast<double>(y) / pheight) + scroll_pos;

			//Reset all hovered panels.
			for (int a = 0;a < static_cast<int>(states.size ());a++)
			{
				if (states[a] == HOVER)
				{
					if (a != panel)
						states[a] = NORMAL;
					else //We are still hovering over the same panel.
						redraw = false;
				}
			}

			//Hopefully not blank space.
			if (panel < static_cast<int>(states.size ()))
			{
				if (states[panel] == NORMAL)
				{
					states[panel] = HOVER;
					
					if (GetWindow () != GetCapture ())
						SetCapture (GetWindow ());
				}

				//If we hover over a down panel, don't do anything, and do not release the mouse.
			}

			if (redraw == true)
				Redraw ();
		}

		return static_cast<LRESULT>(0);
	}
	LRESULT SelectionPanel::OnMouseWheel (WPARAM wparam, LPARAM lparam)
	{
		//Forward this message to our scroll bar.
		SendMessage (scroll.GetWindow (), WM_MOUSEWHEEL, wparam, lparam);
		
		return static_cast<LRESULT>(0);
	}
	LRESULT SelectionPanel::OnPaint (WPARAM wparam, LPARAM lparam)
	{
		HBRUSH normal_brush = CreateSolidBrush (normal_color), hover_brush = CreateSolidBrush (hover_color), down_brush = CreateSolidBrush (down_color), bk_brush = CreateSolidBrush (bk_color), orig_brush;
		HPEN pen = CreatePen (PS_SOLID, 1, RGB (0,0,0)), bord_pen = CreatePen (PS_SOLID, 2, RGB (0,0,0)), orig_pen;
		HBITMAP icon_bmp, orig_bmp;
		RECT wnd_rect, scroll_wnd;
		HFONT font, orig_font;
		HDC dc, dc_mem;
		BITMAP bm_info;
		SIZE tsize;
		int y_pos;

		BeginPaint ();
		dc = BeginOffScreenDC ();
		GetClientRect (GetWindow (), &wnd_rect);
		GetClientRect (scroll.GetWindow (), &scroll_wnd);
		
		//Prepare for drawing.
		font = CreateFont (-MulDiv (font_size, GetDeviceCaps (dc, LOGPIXELSY), 72), 0, 0, 0, 0, false, false, false, 0, 0, 0, 0, 0, this->font.c_str ());

		SetTextColor (dc, RGB (0,0,0));
		SetBkMode (dc, TRANSPARENT);
		orig_font = reinterpret_cast<HFONT>(SelectObject (dc, font));
		orig_brush = reinterpret_cast<HBRUSH>(SelectObject (dc, normal_brush));
		orig_pen = reinterpret_cast<HPEN>(SelectObject (dc, bord_pen));

		//Calculate the position of the text within a panel. Centered vertically, not horozontally.
		::GetTextExtentPoint32 (dc, "TESTING", 7, &tsize);
		y_pos = static_cast<int>((pheight - static_cast<double>(tsize.cy)) / 2);

		//Draw a border, then reselect the thinner pen.
		Rectangle (dc, 0, 0, wnd_rect.right - scroll_wnd.right + 1, wnd_rect.bottom);

		SelectObject (dc, pen);
		
		//Draw how ever many states there are in the vector - that is our official panel count.
		for (int a = scroll_pos; a < scroll_pos + view;a++)
		{
			//Check if out of bounds i.e. we can see more than we have.
			if (static_cast<int>(states.size ()) <= a)
				break;
			
			//For each panel, check its state and draw accordingly.
			if (states[a] == NORMAL)
				SelectObject (dc, normal_brush);
			else if (states[a] == HOVER)
				SelectObject (dc, hover_brush);
			else if (states[a] == DOWN)
				SelectObject (dc, down_brush);

			//Ensure a thick border.
			if (a - scroll_pos == 0)
				Rectangle (dc, 1, static_cast<int>(static_cast<double>(a - scroll_pos) * pheight + 1.5), wnd_rect.right - scroll_wnd.right, static_cast<int>(static_cast<double>(a - scroll_pos + 1) * pheight + 0.5));
			else if (a - scroll_pos == view - 1)
				Rectangle (dc, 1, static_cast<int>(static_cast<double>(a - scroll_pos) * pheight + 0.5), wnd_rect.right - scroll_wnd.right, static_cast<int>(static_cast<double>(a - scroll_pos + 1) * pheight - 0.5));
			else
				Rectangle (dc, 1, static_cast<int>(static_cast<double>(a - scroll_pos) * pheight + 0.5), wnd_rect.right - scroll_wnd.right, static_cast<int>(static_cast<double>(a - scroll_pos + 1) * pheight + 0.5));

			if (!en_icons)
				TextOut (dc, XSHIFT, static_cast<int>(static_cast<double>(a - scroll_pos) * pheight + 0.5) + y_pos, contents[a].c_str (), static_cast<int>(contents[a].length ()));
			else //If icons are enabled, we need to move the text right and put the icon in its place.
			{
				//Load the BMP with original size.
				icon_bmp = reinterpret_cast<HBITMAP>(LoadImage (GetModuleHandle (NULL), icons[a], IMAGE_BITMAP, 0, 0, LR_DEFAULTCOLOR));
				assert (icon_bmp);
				dc_mem = CreateCompatibleDC (dc);
				orig_bmp = reinterpret_cast<HBITMAP>(SelectObject (dc_mem, icon_bmp));
				::GetObject (icon_bmp, sizeof (bm_info), &bm_info);

				//Always stretch the bitmap to become square, and equidistant from both the top and bottom and the left, 5.
				::TransparentBlt (dc, 5, static_cast<int>(static_cast<double>(a - scroll_pos) * pheight + 5.5), static_cast<int>(pheight - 10.0), static_cast<int>(pheight - 10.0), dc_mem, 0, 0, bm_info.bmWidth, bm_info.bmHeight, RGB (0,0,0));

				SelectObject (dc_mem, orig_bmp);
				DeleteObject (icon_bmp);
				DeleteDC (dc_mem);

				TextOut (dc, static_cast<int>(pheight), static_cast<int>(static_cast<double>(a - scroll_pos) * pheight + 0.5) + y_pos, contents[a].c_str (), static_cast<int>(contents[a].length ()));
			}
		}

		//Draw a blank region below our panels if neccessary, that is, if we don't fill up the entire space.
		if (static_cast<int>(states.size ()) <= view)
		{
			SelectObject (dc, bk_brush);

			if (states.size () == 0)
				Rectangle (dc, 1, 1, wnd_rect.right - scroll_wnd.right, wnd_rect.bottom - 1);
			else
				Rectangle (dc, 1, static_cast<int>(static_cast<double>(states.size ()) * pheight), wnd_rect.right - scroll_wnd.right, wnd_rect.bottom - 1);
		}

		SelectObject (dc, orig_brush);
		SelectObject (dc, orig_font);
		SelectObject (dc, orig_pen);
		DeleteObject (pen);
		DeleteObject (bord_pen);
		DeleteObject (normal_brush);
		DeleteObject (hover_brush);
		DeleteObject (down_brush);
		DeleteObject (bk_brush);
		DeleteObject (font);

		EndOffScreenDC ();
		EndPaint ();

		return static_cast<LRESULT>(0);
	}
	LRESULT SelectionPanel::OnScrollBarScroll (WPARAM wparam, LPARAM lparam)
	{
		RECT wnd_rect, scroll_wnd;
		POINT pos;
		int panel;

		scroll_pos = *reinterpret_cast<int *>(wparam);

		//Recalculate the HOVER panel.
		::GetCursorPos (&pos);
		::ScreenToClient (GetWindow (), &pos);

		GetClientRect (GetWindow (), &wnd_rect);
		GetClientRect (scroll.GetWindow (), &scroll_wnd);
		
		//We only need to recalculate if our mouse is actually in the valid region, and if we actually captured the mouse. If the user grabbes the scrollbar, we don't want to calculate this.
		if (GetWindow () == GetCapture () && pos.x >= 0 && pos.x <= wnd_rect.right - scroll_wnd.right && pos.y >= 0 && pos.y <= static_cast<int>(static_cast<double>(contents.size ()) * pheight + 0.5))
		{
			//Determine the panel we are on.
			panel = static_cast<int>(static_cast<double>(pos.y) / pheight) + scroll_pos;

			//Reset all hovered panels.
			for (int a = 0;a < static_cast<int>(states.size ());a++)
				if (states[a] == HOVER)
					states[a] = NORMAL;

			//Hopefully not blank space.
			if (panel < static_cast<int>(states.size ()))
				if (states[panel] == NORMAL)
					states[panel] = HOVER;
		}

		Redraw ();

		return static_cast<LRESULT>(0);
	}
	LRESULT SelectionPanel::OnSize (WPARAM wparam, LPARAM lparam)
	{
		RECT wnd_rect, scroll_wnd;
		
		GetClientRect (GetWindow (), &wnd_rect);
		GetClientRect (scroll.GetWindow (), &scroll_wnd);

		//Resize the scroll window, and recalculate pheight.
		scroll.Resize (scroll_wnd.right, HIWORD (lparam), false);
		scroll.Move (wnd_rect.right - scroll_wnd.right, 0, true);
		pheight = static_cast<double>(HIWORD (lparam)) / static_cast<double>(view);

		return static_cast<LRESULT>(0);
	}
}