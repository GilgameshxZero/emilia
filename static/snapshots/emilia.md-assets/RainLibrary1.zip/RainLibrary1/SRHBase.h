/*
Deprecated
*/

#pragma once
#include "SendRecv.h"
#include "ClientStart.h"
#include "Utility.h"
#include <iostream>
#include <string>
#include <Windows.h>

namespace EBC
{
	struct ExtMessParam
	{
		SOCKET *sock;
		std::queue<std::string> *recvqueue;
		std::string exittext;
		HWND sendwnd;
	};

	DWORD WINAPI SendThread (LPVOID lpParameter);
	LRESULT CALLBACK SendWndProc (HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam);
	void ProcessMessage (void *funcparam);

	//called when recv thread ends
	void OnRecvEnd (void *funcparam); //must terminate send thread
}