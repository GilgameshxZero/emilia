/*
Deprecated
*/

#pragma once

#include "WSA2Include.h"

#include <string>

namespace Rain
{
	typedef int (*WSARecvPMFunc) (void *);
	typedef void (*WSARecvInitFunc) (void *);
	typedef void (*WSARecvExitFunc) (void *);

	class WSARecvParam
	{
		public:
			WSARecvParam ();
			WSARecvParam (SOCKET *sock, std::string *message, int buflen, void *funcparam, WSARecvPMFunc OnProcessMessage, WSARecvInitFunc OnRecvInit, WSARecvExitFunc OnRecvEnd);

			SOCKET *sock;
			std::string *message;
			int buflen;
			void *funcparam;
			WSARecvPMFunc OnProcessMessage; //return nonzero to terminate recv
			WSARecvInitFunc OnRecvInit;
			WSARecvExitFunc OnRecvEnd;
	};
}