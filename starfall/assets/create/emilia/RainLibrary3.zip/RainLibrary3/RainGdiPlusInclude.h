/*
Standard
*/

//Use this include for GDI+ programs.

#pragma once

#include "RainWindowsLAM.h"

#include <objidl.h> //must come before gdiplus.h
#include <gdiplus.h>

#pragma comment (lib, "Gdiplus.lib")