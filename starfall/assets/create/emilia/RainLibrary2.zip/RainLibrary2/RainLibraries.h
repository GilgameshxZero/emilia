/*
Standard
*/

/*
This include should include all current and legacy Rain library headers.

To use the libraries, all files in the RainLibraryX directory must be added to the project (externally is fine).
*/

#include "RainError.h"
#include "RainGdiplusInclude.h"
#include "RainLogging.h"
#include "RainUtility.h"
#include "RainWindow.h"
#include "RainWindowsLAM.h"
#include "RainWSA2.h"