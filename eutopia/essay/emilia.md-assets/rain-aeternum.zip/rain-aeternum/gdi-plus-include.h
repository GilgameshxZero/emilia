/*
Standard
*/

//Use this include for GDI+ programs.

#pragma once

#pragma comment (lib, "Gdiplus.lib")

#include "windows-lam-include.h"

#include <objidl.h> //must come before gdiplus.h
#include <gdiplus.h>