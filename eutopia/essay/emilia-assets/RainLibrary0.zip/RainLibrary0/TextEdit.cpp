#include <cassert>
#include "TextEdit.h"

namespace Rain
{
	TextEdit::TextEdit () : CARETWIDTH (2), XSHIFT (5), YSHIFT (5)
	{
	}
	TextEdit::~TextEdit ()
	{
	}

	void TextEdit::Initialize (HWND parent, bool multi_line)
	{
		TEXTMETRIC tm;
		HCURSOR cursor;
		HFONT orig_font;
		RECT wnd_rect;
		HDC dc;

		//Use the IBEAM cursor.
		cursor = static_cast<HCURSOR>(::LoadImage (NULL, IDC_IBEAM, IMAGE_CURSOR, 0, 0, LR_SHARED));

		Window::Initialize (CS_HREDRAW | CS_VREDRAW); //If we resize, we will repaint, and thus trigger recalculation of lines and updating of the scrollbar.
		SetStyle (WS_CHILD | WS_CLIPCHILDREN);
		SetParent (parent);
		
		RedefineMessage (WM_CHAR, static_cast<LRESULT (Rain::Window::*) (WPARAM, LPARAM)>(&TextEdit::OnChar));
		RedefineMessage (WM_ERASEBKGND, static_cast<LRESULT (Rain::Window::*) (WPARAM, LPARAM)>(&TextEdit::OnEraseBkgnd));
		RedefineMessage (WM_HOTKEY, static_cast<LRESULT (Rain::Window::*) (WPARAM, LPARAM)>(&TextEdit::OnHotKey));
		RedefineMessage (WM_KEYDOWN, static_cast<LRESULT (Rain::Window::*) (WPARAM, LPARAM)>(&TextEdit::OnKeyDown));
		RedefineMessage (WM_KILLFOCUS, static_cast<LRESULT (Rain::Window::*) (WPARAM, LPARAM)>(&TextEdit::OnKillFocus));
		RedefineMessage (WM_LBUTTONUP, static_cast<LRESULT (Rain::Window::*) (WPARAM, LPARAM)>(&TextEdit::OnLButtonUp));
		RedefineMessage (WM_LBUTTONDOWN, static_cast<LRESULT (Rain::Window::*) (WPARAM, LPARAM)>(&TextEdit::OnLButtonDown));
		RedefineMessage (WM_MOUSEMOVE, static_cast<LRESULT (Rain::Window::*) (WPARAM, LPARAM)>(&TextEdit::OnMouseMove));
		RedefineMessage (WM_MOUSEWHEEL, static_cast<LRESULT (Rain::Window::*) (WPARAM, LPARAM)>(&TextEdit::OnMouseWheel));
		RedefineMessage (WM_PAINT, static_cast<LRESULT (Rain::Window::*) (WPARAM, LPARAM)>(&TextEdit::OnPaint));
		RedefineMessage (WM_SCROLLBARSCROLL, static_cast<LRESULT (Rain::Window::*) (WPARAM, LPARAM)>(&TextEdit::OnScrollBarScroll));
		RedefineMessage (WM_SETFOCUS, static_cast<LRESULT (Rain::Window::*) (WPARAM, LPARAM)>(&TextEdit::OnSetFocus));
		RedefineMessage (WM_SIZE, static_cast<LRESULT (Rain::Window::*) (WPARAM, LPARAM)>(&TextEdit::OnSize));

		//Local variables.
		dc = ::GetDC (GetWindow ());

		scroll.Initialize (GetWindow ());
		scroll.SetView (0, 0);
		scroll.Show ();

		font = ::CreateFont (-MulDiv (12, GetDeviceCaps (dc, LOGPIXELSY), 72), 0, 0, 0, 0, false, false, false, 0, 0, 0, 0, 0, "Courier New");
		this->multi_line = multi_line;
		line_pos = 0;
		caret_pos = 0;
		sel_pivot = 0;
		text = "";
		tracking = false;

		//Calculate spacing.
		orig_font = reinterpret_cast<HFONT>(::SelectObject (dc, this->font));
		::GetTextMetrics (dc, &tm);
		char_x = tm.tmAveCharWidth;
		char_y = tm.tmHeight;

		::GetClientRect (GetWindow (), &wnd_rect);
		view = (wnd_rect.bottom - YSHIFT * 2) / char_y;
		char_pline = (wnd_rect.right - XSHIFT * 2) / char_x;
		total = 0;
		//x_space = static_cast<float>(wnd_rect.right - XSHIFT * 2 - char_x * char_pline) / static_cast<float>(char_pline - 1);
		y_space = static_cast<float>(wnd_rect.bottom - YSHIFT * 2 - char_y * view) / static_cast<float>(view - 1);

		::SelectObject (dc, orig_font);
		::ReleaseDC (GetWindow (), dc);
		::DestroyCursor (cursor);
	}
	void TextEdit::Destroy ()
	{
		//Delete our font before we end.
		::DeleteObject (font);

		Window::Destroy ();
	}

	void TextEdit::SetFontSize (int size)
	{
		HFONT orig_font;
		TEXTMETRIC tm;
		RECT wnd_rect;
		HDC dc;

		assert (GetWindow ());
		
		::DeleteObject (font);
		dc = ::GetDC (GetWindow ());
		font = ::CreateFont (-MulDiv (size, GetDeviceCaps (dc, LOGPIXELSY), 72), 0, 0, 0, 0, false, false, false, 0, 0, 0, 0, 0, "Courier New");

		//Need to change caret height, and update spacing.
		::DestroyCaret ();

		orig_font = reinterpret_cast<HFONT>(::SelectObject (dc, this->font));
		::GetTextMetrics (dc, &tm);
		::CreateCaret (GetWindow (), NULL, CARETWIDTH, tm.tmHeight);
		::ShowCaret (GetWindow ());

		char_x = tm.tmAveCharWidth;
		char_y = tm.tmHeight;

		::GetClientRect (GetWindow (), &wnd_rect);
		view = (wnd_rect.bottom - YSHIFT * 2) / char_y;
		char_pline = (wnd_rect.right - XSHIFT * 2) / char_x;
		total = ceil (static_cast<float>(text.length ()) / static_cast<float>(char_pline));
		//x_space = static_cast<float>(wnd_rect.right - XSHIFT * 2 - char_x * char_pline) / static_cast<float>(char_pline - 1);
		y_space = static_cast<float>(wnd_rect.bottom - YSHIFT * 2 - char_y * view) / static_cast<float>(view - 1);

		//It's dangerous to keep line_pos the same, so reset it. Reset the scrollbar too.
		line_pos = 0;
		scroll.SetView (0, 0); //Resets pos.
		scroll.SetView (view, total);

		::SelectObject (dc, orig_font);
		::ReleaseDC (GetWindow (), dc);

		Redraw ();
	}
	void TextEdit::SetText (std::string new_text)
	{
		assert (GetWindow ());

		text = new_text;
		line_pos = 0;
		total = ceil (static_cast<float>(text.length ()) / static_cast<float>(char_pline));
		scroll.SetView (0, 0); //Resets pos.
		scroll.SetView (view, total);

		//Position the caret at the end of the text.
		caret_pos = text.length ();
		sel_pivot = caret_pos;

		Redraw ();
	}
	void TextEdit::SetScrollWidth (int width)
	{
		RECT wnd_rect, edit_wnd;
		
		assert (GetWindow ());

		GetClientRect (scroll.GetWindow (), &edit_wnd);
		GetClientRect (GetWindow (), &wnd_rect);
		scroll.Resize (width, edit_wnd.bottom, false);
		scroll.Move (wnd_rect.right - width, edit_wnd.bottom, true);
		
		Redraw ();
	}
	void TextEdit::SetScrollInterval (int interval)
	{
		assert (GetWindow ());

		scroll.SetScrollInt (interval);

		//No need to redraw, because nothing has changed.
	}
	
	LRESULT TextEdit::OnChar (WPARAM wparam, LPARAM lparam)
	{
		//32-126, 9 (TAB), 10 (NEWLINE), BACKSPACE. Only add TAB if the character before caret_pos (or sel_pivot, whichever is smaller) is either TAB or NEWLINE. Redraw after, and change caret_pos & sel_pivot accordingly (+1). If caret_pos != sel_pivot, clear the characters in between, and repalce with whatever was typed, unless we have a BACKSPACE.

		return static_cast<LRESULT>(0);
	}
	LRESULT TextEdit::OnEraseBkgnd (WPARAM wparam, LPARAM lparam)
	{
		return static_cast<LRESULT>(1);
	}
	LRESULT TextEdit::OnHotKey (WPARAM wparam, LPARAM lparam)
	{
		//CRTL+C, CTRL+X, CTRL+V, CTRL+A. Use clipboard functions. Do nothing for the first 3 if caret_pos == sel_pivot. See notes in TextEdit.h. For CTRL+A, place caret_pos = text.length (), and sel_pivot = 0;

		return static_cast<LRESULT>(0);
	}
	LRESULT TextEdit::OnKeyDown (WPARAM wparam, LPARAM lparam)
	{
		//LEFT, RIGHT, UP, DOWN, DELETE. Ignore SHIFT for now (expansion). Always use caret_pos in calculations for LEFT, RIGHT, UP, and DOWN. Translate into coordinates, and shift by whatever direction & height, if UP or DOWN. LEFT and RIGHT are easier. For DELETE, if caret_pos == sel_pivot, just delete the character after. If !=, then delete all that is inbetween.

		return static_cast<LRESULT>(1);
	}
	LRESULT TextEdit::OnKillFocus (WPARAM wparam, LPARAM lparam)
	{
		//DestroyCaret.
		::DestroyCaret ();

		return static_cast<LRESULT>(0);
	}
	LRESULT TextEdit::OnLButtonUp (WPARAM wparam, LPARAM lparam)
	{
		//Tracking = false.
		tracking = false;

		return static_cast<LRESULT>(0);
	}
	LRESULT TextEdit::OnLButtonDown (WPARAM wparam, LPARAM lparam)
	{
		//Will trigger WM_SETFOCUS, and create and show the caret at the right position.
		::SetFocus (GetWindow ());
		
		//If MK_SHIFT, set sel_pivot = caret_pos, and caret_pos = POINT. If not, set caret_pos = sel_pivot = POINT. Also SetCapture, and tracking = true.

		return static_cast<LRESULT>(0);
	}
	LRESULT TextEdit::OnMouseMove (WPARAM wparam, LPARAM lparam)
	{
		//If tracking == true, then adjust caret_pos = POINT.

		return static_cast<LRESULT>(0);
	}
	LRESULT TextEdit::OnMouseWheel (WPARAM wparam, LPARAM lparam)
	{
		//Forward this to our scroll bar.

		return static_cast<LRESULT>(0);
	}
	LRESULT TextEdit::OnPaint (WPARAM wparam, LPARAM lparam)
	{
		HFONT orig_font;
		RECT wnd_rect;
		SIZE tsize;
		HDC dc;

		BeginPaint ();
		dc = BeginOffScreenDC ();

		::GetClientRect (GetWindow (), &wnd_rect);

		::SetTextColor (dc, RGB (0,0,0));
		::SetBkMode (dc, TRANSPARENT);
		orig_font = reinterpret_cast<HFONT>(SelectObject (dc, font));

		//HideCaret, draw, then ShowCaret at the correct position. See notes.
		::HideCaret (GetWindow ());

		for (int a = line_pos * char_pline;a < text.length ();a += char_pline)
		{
			
		}

		::GetTextExtentPoint32 (dc, text.c_str (), static_cast<int>(text.length ()), &tsize);
		::TextOut (dc, (wnd_rect.right - wnd_rect.left - tsize.cx) / 2, (wnd_rect.bottom - wnd_rect.top - tsize.cy) / 2, text.c_str (), static_cast<int>(text.length ()));
		
		::ShowCaret (GetWindow ());
		::SelectObject (dc, orig_font);

		EndOffScreenDC ();
		EndPaint ();

		return static_cast<LRESULT>(0);
	}
	LRESULT TextEdit::OnScrollBarScroll (WPARAM wparam, LPARAM lparam)
	{
		//Change the line_pos and redraw.
		line_pos = *reinterpret_cast<int *>(wparam);

		Redraw ();

		return static_cast<LRESULT>(0);
	}
	LRESULT TextEdit::OnSetFocus (WPARAM wparam, LPARAM lparam)
	{
		//CreateCaret, ShowCaret.
		::CreateCaret (GetWindow (), NULL, CARETWIDTH, char_y);
		::ShowCaret (GetWindow ());

		return static_cast<LRESULT>(0);
	}
	LRESULT TextEdit::OnSize (WPARAM wparam, LPARAM lparam)
	{
		TEXTMETRIC tm;
		RECT wnd_rect;

		//Do not redraw (covered by CS_HREDRAW and CS_VREDRAW). Instead, recalculate spacing for WM_PAINT.
		::GetClientRect (GetWindow (), &wnd_rect);
		view = (wnd_rect.bottom - YSHIFT * 2) / char_y;
		char_pline = (wnd_rect.right - XSHIFT * 2) / char_x;
		total = ceil (static_cast<float>(text.length ()) / static_cast<float>(char_pline));
		//x_space = static_cast<float>(wnd_rect.right - XSHIFT * 2 - char_x * char_pline) / static_cast<float>(char_pline - 1);
		y_space = static_cast<float>(wnd_rect.bottom - YSHIFT * 2 - char_y * view) / static_cast<float>(view - 1);

		//It's dangerous to keep line_pos the same, so reset it. Reset the scrollbar too.
		line_pos = 0;
		scroll.SetView (0, 0); //Resets pos.
		scroll.SetView (view, total);

		return static_cast<LRESULT>(0);
	}
}