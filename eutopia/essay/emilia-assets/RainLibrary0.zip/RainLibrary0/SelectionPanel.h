#ifndef RAIN_SELECTIONPANEL
#define RAIN_SELECTIONPANEL

#include <string>
#include <Windows.h>
#include "ScrollBar.h"
#include "Window.h"

//TODO.
#define	WM_DBLCLKPANEL		WM_APP + 2
#define	WM_SELECTIONCHANGE	WM_APP + 3

namespace Rain
{
	//Make multi-select a toggle option. Also, allow icons to be displayed next to panels for other purposes.
	class SelectionPanel : public Window
	{
		public:
			SelectionPanel ();
			~SelectionPanel ();

			void	Initialize	(HWND parent, bool en_multi = false, bool en_icons = false);
			void	Destroy		();

			//The following functions are usable only after initialization. The icons in SetContents muse be a resource. Use MAKEINTRESOURCE. The user does not have to set icons for the contents. All the values below have defaults, except the contents.
			void	SetContents				(std::vector<std::string> new_contents);
			void	SetIcons				(std::vector<LPCTSTR> new_icons); //Requires en_icons to be true, or assert error. Black is transparent.
			void	SetScrollInterval		(int new_interval);
			void	SetScrollWidth			(int new_width);
			void	SetView					(int new_view);
			void	SetColors				(COLORREF new_normal_color, COLORREF new_hover_color, COLORREF new_down_color, COLORREF new_bk_color);
			void	SetFont					(std::string new_font);
			void	SetFontSize				(int new_size);

			std::vector<int>	GetSelection	();

		private:
			LRESULT	OnEraseBkgnd		(WPARAM wparam, LPARAM lparam);
			LRESULT	OnLButtonDown		(WPARAM wparam, LPARAM lparam);
			LRESULT	OnLButtonUp			(WPARAM wparam, LPARAM lparam);
			LRESULT	OnMouseMove			(WPARAM wparam, LPARAM lparam);
			LRESULT	OnMouseWheel		(WPARAM wparam, LPARAM lparam);
			LRESULT	OnPaint				(WPARAM wparam, LPARAM lparam);
			LRESULT OnScrollBarScroll	(WPARAM wparam, LPARAM lparam);
			LRESULT	OnSize				(WPARAM wparam, LPARAM lparam);

			Window::SetUserData;
			Window::SetLargeIcon;
			Window::SetSmallIcon;
			Window::SetExStyle;
			Window::SetStyle;
			Window::SetTitleText;
			//Window::SetParent;

			Window::BeginOffScreenDC;
			Window::EndOffScreenDC;
			Window::BeginPaint;
			Window::EndPaint;

			Window::GetUserData;
			//Window::GetParent;

			Window::RedefineMessage;
			Window::ClearMessages;

			//States
			const int		NORMAL;
			const int		HOVER;
			const int		DOWN;

			//X-pos of the text.
			const int		XSHIFT;

			COLORREF normal_color, hover_color, down_color, bk_color;
			int view, scroll_pos, focus_panel, font_size;
			std::vector<std::string> contents;
			std::vector<LPCTSTR> icons;
			std::vector<int> states; //Official total number of panels
			bool en_multi, en_icons; //Enable multi-select or icons, or both?
			Rain::ScrollBar scroll;
			std::string font;
			double pheight; //Panel height.
	};
}

#endif