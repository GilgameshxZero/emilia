#ifndef RAINCORPORATION_FILEEDIT
#define RAINCORPORATION_FILEEDIT

#include <propsys.h>
#include <shobjidl.h>
#include <shlwapi.h>
#include <string>
#include <windows.h>

/*A few notes on the dialog that are important when including FileEdit. Open up the property pages for the current project that needs the FileEdit files. Navigate to Configuration Properties->Linker->Input. In the Additional Dependencies blank, edit it. Add these three lines to the text edit shown there:

propsys.lib
shlwapi.lib
comctl32.lib

This will resolve 2 LNK2019 errors while building. This is taken from a Microsoft project, and therefore preferably not to be messed with.
*/

namespace RainCorporation
{
	namespace FileEdit
	{
		extern const COMDLG_FILTERSPEC	DIALOGTYPES[];
		extern const std::string		FILEEDITFONT;
		extern const int				DEFAULTHEIGHT;
		extern const int				WORDYSHIFT;

		class FileEdit
		{
			public:
				FileEdit (void);
				void Initialize (HWND parent, int width, bool open); //Creates the window and draws everything on the window, but hides the window.

				void Show (int x, int y); //Shows the window at the coordinates.
				void Hide (); //Hides the window.

				void SetPath (std::string new_path);
				std::string GetPath ();

			private:
				void Draw (); //Draws the edit on the window.

				//Functions for the message handler, a friend.
				void CheckMove (int x, int y);
				void CheckUp (int x, int y);
				void CheckDown (int x, int y);

				bool open;
				int cx; //Dimensions.
				std::string file_path;
				std::string state;
				HWND parent_wnd, edit_wnd;

				//A lot of code is needed for the custom item dialog. It is included in the same file, in this class for simplicity. It's best not to mess with the code.
				class CDialogEventHandler : public IFileDialogEvents, public IFileDialogControlEvents
				{
					public:
						// IUnknown methods.
						IFACEMETHODIMP QueryInterface (REFIID riid, void** ppv)
						{
							static const QITAB qit[] = {
								QITABENT (CDialogEventHandler, IFileDialogEvents),
								QITABENT (CDialogEventHandler, IFileDialogControlEvents),
								{ 0 },
							};

							return QISearch (this, qit, riid, ppv);
						}
						IFACEMETHODIMP_ (ULONG) AddRef ()
						{
							return InterlockedIncrement (&_cRef);
						}
						IFACEMETHODIMP_ (ULONG) Release ()
						{
							long cRef = InterlockedDecrement (&_cRef);

							if (!cRef)
								delete this;

							return cRef;
						}

						// IFileDialogEvents methods.
						IFACEMETHODIMP OnFileOk (IFileDialog *) { return S_OK; };
						IFACEMETHODIMP OnFolderChange (IFileDialog *) { return S_OK; };
						IFACEMETHODIMP OnFolderChanging (IFileDialog *, IShellItem *) { return S_OK; };
						IFACEMETHODIMP OnHelp (IFileDialog *) { return S_OK; };
						IFACEMETHODIMP OnSelectionChange (IFileDialog *) { return S_OK; };
						IFACEMETHODIMP OnShareViolation (IFileDialog *, IShellItem *, FDE_SHAREVIOLATION_RESPONSE *) { return S_OK; };
						IFACEMETHODIMP OnTypeChange (IFileDialog *pfd);
						IFACEMETHODIMP OnOverwrite (IFileDialog *, IShellItem *, FDE_OVERWRITE_RESPONSE *) { return S_OK; };

						// IFileDialogControlEvents methods.
						IFACEMETHODIMP OnItemSelected (IFileDialogCustomize *pfdc, DWORD dwIDCtl, DWORD dwIDItem);
						IFACEMETHODIMP OnButtonClicked (IFileDialogCustomize *, DWORD) { return S_OK; };
						IFACEMETHODIMP OnCheckButtonToggled (IFileDialogCustomize *, DWORD, BOOL) { return S_OK; };
						IFACEMETHODIMP OnControlActivating (IFileDialogCustomize *, DWORD) { return S_OK; };

						CDialogEventHandler () : _cRef (1) { };

					private:
						~CDialogEventHandler () { };
						long _cRef;
				};
				HRESULT CDialogEventHandler_CreateInstance(REFIID riid, void **ppv);
				

			//Friend the message handler so that it can access the Check functions.
			friend LRESULT CALLBACK FileEditProc (HWND edit_wnd, UINT msg, WPARAM wParam, LPARAM lParam);
		};
	}
}

#endif