#ifndef RAIN_BUTTON
#define RAIN_BUTTON

#include <string>
#include <Windows.h>
#include "Window.h"

//Passed to the parent window. The WPARAM is a pointer to the Button object. The LPARAM is not used.
#define	WM_BUTTONPRESS	WM_APP + 0

namespace Rain
{
	class Button : public Window
	{
		public:
			Button ();
			~Button ();

			void	Initialize	(HWND parent);
			void	Destroy		();

			//Usable only after initialization. Note this is not like HostWndBtn, in that we don't need to call these functions before we can draw. The values have default values in Rain::Button.
			void	SetText		(std::string new_text);
			void	SetFont		(std::string new_font);
			void	SetFontSize	(int new_size);
			void	SetColors	(COLORREF normal_color, COLORREF hover_color, COLORREF drag_color, COLORREF down_color);

		private:
			LRESULT	OnPaint			(WPARAM wparam, LPARAM lparam);
			LRESULT	OnLButtonUp		(WPARAM wparam, LPARAM lparam);
			LRESULT	OnLButtonDown	(WPARAM wparam, LPARAM lparam);
			LRESULT	OnMouseMove		(WPARAM wparam, LPARAM lparam);
			LRESULT	OnEraseBkgnd	(WPARAM wparam, LPARAM lparam);

			//Restrictions and such.
			Window::SetUserData; //Reserved for Rain::Window functions.
			Window::SetLargeIcon;
			Window::SetSmallIcon;
			Window::SetExStyle;
			Window::SetStyle;
			Window::SetTitleText;
			//Window::SetParent; //Pretty vital to client, actually.

			Window::BeginOffScreenDC;
			Window::EndOffScreenDC;
			Window::BeginPaint;
			Window::EndPaint;

			Window::GetUserData;
			//Window::GetParent;

			Window::RedefineMessage;
			Window::ClearMessages;

			//Window::GetWindow

			const int		NORMAL;
			const int		HOVER;
			const int		DRAG;
			const int		DOWN;

			//Color of the button at various states.
			COLORREF normal_color, hover_color, drag_color, down_color;

			std::string text, font;
			int font_size, state;
	};
}

#endif