#include <cassert>
#include <sstream>
#include <string>
#include <Windows.h>
#include "Window.h"

namespace Rain
{
	Window::Window ()
	{
		//This is a test for initialization.
		window = NULL;
	}
	Window::~Window ()
	{
		//The user should manually destroy the window, because they manually initialized it. This should apply in all derived classes too.
	}

	void Window::Initialize (UINT wc_style, HCURSOR cursor)
	{
		//Local variables. Relations are cleared everytime the window is initialized.
		paint_struct = PAINTSTRUCT ();
		bm_mem = bm_old = NULL;
		func_rel.clear ();
		dc_mem = NULL;

		//Check for cursor. We want cursor to default to NULL instead of IDC_ARROW because we want to destroy any cursor we created ourselves, but not any that were passed to us.
		bool cursor_flag = true; //Whether we created the cursor in this function or not.

		if (cursor == NULL)
			cursor = static_cast<HCURSOR>(::LoadImage (NULL, IDC_ARROW, IMAGE_CURSOR, 0, 0, LR_SHARED));
		else
			cursor_flag = false;

		std::string class_name = GenerateClassName ();
		
		WNDCLASSEX wnd_class;

		wnd_class.cbSize        = sizeof (WNDCLASSEX);
		wnd_class.style         = wc_style;
		wnd_class.lpfnWndProc   = Rain::Window::WndProc;
		wnd_class.cbClsExtra    = 0;
		wnd_class.cbWndExtra    = 0;
		wnd_class.hInstance     = GetModuleHandle (NULL);
		wnd_class.hIcon         = NULL;
		wnd_class.hCursor       = cursor;
		wnd_class.hbrBackground = reinterpret_cast<HBRUSH>(COLOR_WINDOW + 1);
		wnd_class.lpszMenuName  = NULL;
		wnd_class.lpszClassName = class_name.c_str ();
		wnd_class.hIconSm       = NULL;

		bool temp = (::RegisterClassEx (&wnd_class) != 0);
		assert (temp);

		window = ::CreateWindowEx (NULL, class_name.c_str (), "", WS_POPUP, 0, 0, 0, 0, NULL, NULL, GetModuleHandle (NULL), NULL);
		SetUserData (this);
		::UpdateWindow (window);

		//If we created the cursor automatically.
		if (cursor_flag == true)
			::DestroyCursor (cursor);

		//Showing the window is left up to the user.
	}
	void Window::Destroy ()
	{
		bool temp = (::DestroyWindow (window) != 0);
		assert (temp);
	}

	void Window::Resize (int cx, int cy, bool redraw)
	{
		assert (window);

		RECT wnd_rect;

		::GetWindowRect (window, &wnd_rect);

		if (::IsChild (::GetDesktopWindow (), window)) //The window is not a child.
			::MoveWindow (window, wnd_rect.left, wnd_rect.top, cx, cy, redraw);
		else //The window is a child.
		{
			POINT top_left;
			HWND parent = ::GetParent (window);

			top_left.x = wnd_rect.left;
			top_left.y = wnd_rect.top;

			::ScreenToClient (::GetParent (window), &top_left);
			::MoveWindow (window, top_left.x, top_left.y, cx, cy, redraw);
		}
	}
	void Window::Move (int x, int y, bool redraw)
	{
		RECT wnd_rect;
		
		assert (window);
		::GetWindowRect (window, &wnd_rect);
		::MoveWindow (window, x, y, wnd_rect.right - wnd_rect.left, wnd_rect.bottom - wnd_rect.top, redraw);
	}
	void Window::Show (int show)
	{
		assert (window);
		::ShowWindow (window, show);
	}
	void Window::Hide ()
	{
		assert (window);
		::ShowWindow (window, SW_HIDE);
	}
	void Window::Redraw ()
	{
		assert (window);

		RECT wnd_rect;

		::GetClientRect (window, &wnd_rect);
		::InvalidateRect (window, &wnd_rect, true);
		::UpdateWindow (window);
	}

	void Window::SetUserData (void *user_data)
	{
		assert (window);
		::SetWindowLongPtr (window, GWLP_USERDATA, reinterpret_cast<LONG_PTR>(user_data));
	}
	void Window::SetLargeIcon (HICON new_icon)
	{
		assert (window);
		::DefWindowProc (window, WM_SETICON, ICON_BIG, reinterpret_cast<LPARAM>(new_icon));
	}
	void Window::SetSmallIcon (HICON new_icon)
	{
		assert (window);
		::DefWindowProc (window, WM_SETICON, ICON_SMALL, reinterpret_cast<LPARAM>(new_icon));
	}
	void Window::SetExStyle (DWORD new_style)
	{
		assert (window);
		::SetWindowLongPtr (window, GWL_EXSTYLE, new_style);
	}
	void Window::SetStyle (DWORD new_style)
	{
		assert (window);
		::SetWindowLongPtr (window, GWL_STYLE, new_style);
	}
	void Window::SetTitleText (std::string new_title)
	{
		assert (window);
		::SetWindowText (window, new_title.c_str ());
	}
	void Window::SetParent (HWND new_parent)
	{
		assert (window);
		::SetParent (window, new_parent);
	}
	void Window::SetParent (Window *new_parent)
	{
		assert (window);
		::SetParent (window, new_parent->GetWindow ());
	}

	HDC Window::BeginOffScreenDC ()
	{
		assert (window);

		RECT wnd_rect;
		
		::GetClientRect (window, &wnd_rect);

		dc_mem = ::CreateCompatibleDC (paint_struct.hdc);
		bm_mem = ::CreateCompatibleBitmap (paint_struct.hdc, wnd_rect.right - wnd_rect.left, wnd_rect.bottom - wnd_rect.top);
		bm_old = reinterpret_cast<HBITMAP>(::SelectObject (dc_mem, bm_mem));

		HBRUSH white_brush = ::CreateSolidBrush (RGB (255,255,255));

		::FillRect (dc_mem, &wnd_rect, white_brush);
		DeleteObject (white_brush);

		return dc_mem;
	}
	void Window::EndOffScreenDC ()
	{
		assert (window);

		RECT wnd_rect;
		
		::GetClientRect (window, &wnd_rect);

		::BitBlt (paint_struct.hdc, wnd_rect.left, wnd_rect.top, wnd_rect.right, wnd_rect.bottom, dc_mem, 0, 0, SRCCOPY);

		//Release and free objects.
		::SelectObject (dc_mem, bm_old);
		::DeleteObject (bm_mem);
		::DeleteDC (dc_mem);
	}
	HDC Window::BeginPaint ()
	{
		assert (window);
		return ::BeginPaint (window, &paint_struct);
	}
	void Window::EndPaint ()
	{
		assert (window);
		::EndPaint (window, &paint_struct);
	}

	void *Window::GetUserData ()
	{
		assert (window);
		return reinterpret_cast<void *>(::GetWindowLongPtr (window, GWLP_USERDATA));
	}
	HWND Window::GetParent ()
	{
		assert (window);
		return ::GetParent (window);
	}
	HWND Window::GetWindow ()
	{
		return window;
	}

	void Window::RedefineMessage (UINT message, LRESULT (Window::*new_function) (WPARAM, LPARAM))
	{
		assert (window);

		if (new_function != NULL)
		{
			FunctionRelation new_rel;

			//Mark the other function pointer as NULL so we know to use this pointer.
			new_rel.message = message;
			new_rel.mfunc = new_function;
			new_rel.func = NULL;

			//Loop through the array, and delete any relations with the same message, before adding in this one.
			for (int a = 0;a < static_cast<int>(func_rel.size ());a++)
			{
				if (func_rel[a].message == message)
				{
					func_rel.erase (func_rel.begin () + a--);
					break; //There couldn't be more than one if we do this procedure every time.
				}
			}

			//Add this relation.
			func_rel.push_back (new_rel);
		}
		else //If they pass a NULL function, then remove that message instead.
		{
			for (int a = 0;a < static_cast<int>(func_rel.size ());a++)
			{
				if (func_rel[a].message == message)
				{
					func_rel.erase (func_rel.begin () + a--);
					break;
				}
			}
		}
	}
	void Window::RedefineMessage (UINT message, LRESULT (*new_function) (WPARAM, LPARAM))
	{
		assert (window);

		if (new_function != NULL)
		{
			FunctionRelation new_rel;

			new_rel.message = message;
			new_rel.mfunc = NULL;
			new_rel.func = new_function;

			for (int a = 0;a < static_cast<int>(func_rel.size ());a++)
			{
				if (func_rel[a].message == message)
				{
					func_rel.erase (func_rel.begin () + a--);
					break;
				}
			}

			func_rel.push_back (new_rel);
		}
		else
		{
			for (int a = 0;a < static_cast<int>(func_rel.size ());a++)
			{
				if (func_rel[a].message == message)
				{
					func_rel.erase (func_rel.begin () + a--);
					break;
				}
			}
		}
	}
	void Window::ClearMessages ()
	{
		func_rel.clear ();
	}

	LRESULT CALLBACK Window::WndProc (HWND window, UINT msg, WPARAM wparam, LPARAM lparam)
	{
		Rain::Window *user_data = reinterpret_cast<Rain::Window *>(::GetWindowLongPtr (window, GWLP_USERDATA));

		//Loop through our function relations and call those functions. Else, just return DefWindowProc. Assume the window has been created.
		if (user_data != NULL) //Do not call any messages if we have just created our window, and have not set USERDATA yet.
		{
			for (int a = 0;a < static_cast<int>(user_data->func_rel.size ());a++)
			{
				if (user_data->func_rel[a].message == msg)
				{
					if (user_data->func_rel[a].func == NULL)
						return (user_data->*(user_data->func_rel[a].mfunc)) (wparam, lparam);
					else if (user_data->func_rel[a].mfunc == NULL)
						return (*user_data->func_rel[a].func) (wparam, lparam);
				}
			}
		}

		return DefWindowProc (window, msg, wparam, lparam);
	}
	
	std::string Window::GenerateClassName ()
	{
		std::stringstream sstream;
		static int cn_id; //Use this variable to create unique class names.

		sstream << "Rain::Window: " << cn_id++;

		return sstream.str ();
	}
}