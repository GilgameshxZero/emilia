#ifndef RAIN_WINDOW
#define RAIN_WINDOW

#include <string>
#include <vector>
#include <Windows.h>

//Applications can use messages starting from WM_AVAILIBLE, if they import RAIN library.
#define WM_AVAILIBLE	WM_APP + 4

//Do not mess with USERDATA of windows created by this class.
namespace Rain
{
	//Mainly a base classes for all windows in every program, but can be used by itself. Return false for error. Allow unpacking of HWND, along with the packing too. Loose error checking with ASSERT and VERIFY.
	class Window
	{
		public:
			Window	();
			~Window	();

			//These functions are needed in all derived classes. Virtual if derived classes need to add something. User should NEVER try to initialize HWND himself, may cause problems.
			virtual void	Initialize	(UINT wc_style = NULL, HCURSOR cursor = NULL);
			virtual void	Destroy		(); //Does not clear message relations. Use Initialize () or Clear Messages ().

			//These functions should be availible for all users, and are not virtual to be redefined. Can only be used after initialization of HWND.
			void	Resize	(int cx, int cy, bool redraw = false);
			void	Move	(int x, int y, bool redraw = false);
			void	Show	(int show = SW_SHOW);
			void	Hide	();
			void	Redraw	();

			//Virtual, in case the derived class wants these functions as private or protected. We define these functions because they are pretty useful and often used, while others are not. Can only be used after initialization of HWND.
			virtual void	SetUserData		(void *user_data);
			virtual void	SetLargeIcon	(HICON new_icon);
			virtual void	SetSmallIcon	(HICON new_icon);
			virtual void	SetExStyle		(DWORD new_style);
			virtual void	SetStyle		(DWORD new_style);
			virtual void	SetTitleText	(std::string new_title);
			virtual void	SetParent		(HWND new_parent);
			virtual void	SetParent		(Window *new_parent);

			//Save code later, by using these functions. Can be redefined by derived classes. Can only be used after initialization of HWND.
			virtual HDC		BeginOffScreenDC	();
			virtual void	EndOffScreenDC		();
			virtual	HDC		BeginPaint			();
			virtual	void	EndPaint			();

			//Virtual in case derived class wants to hide access. Can only be used after initialization of HWND.
			virtual void	*GetUserData	();
			virtual HWND	GetParent		();

			virtual HWND	GetWindow		(); //Can be used before initialization.

			//This function lets the user redefine the function to be called for a particular message. During initialization, relations are cleared. Usable only after initialization. Pass NULL to new_function to remove the message.
			virtual void	RedefineMessage	(UINT message, LRESULT (Window::*new_function) (WPARAM, LPARAM));
			virtual void	RedefineMessage	(UINT message, LRESULT (*new_function) (WPARAM, LPARAM));
			virtual void	ClearMessages	(); //Usable before initialization.

		private:
			//Stores which function to call for which message.
			struct FunctionRelation
			{
				UINT message;

				//Store two functions here, so that a message can call a function outside a derived class too. Only one function should be valid.
				LRESULT (Window::*mfunc)	(WPARAM, LPARAM);
				LRESULT (*func)				(WPARAM, LPARAM);
			};

			//This is our WNDPROC function. It is not exposed to the user, and automatically equipped onto the window from Initialize.
			static LRESULT CALLBACK	WndProc	(HWND window, UINT msg, WPARAM wparam, LPARAM lparam);
			
			//Generates a unique class name for each window. Not needed outside this class.
			std::string	GenerateClassName	();
			
			//The window.
			HWND	window;

			//Variables for the Off-Screen DC, only for this class.
			HBITMAP	bm_mem, bm_old;
			HDC		dc_mem;

			//Variable for BeginPaint and EndPaint.
			PAINTSTRUCT paint_struct;

			//Vector to store which function to use for which message.
			std::vector<FunctionRelation>	func_rel;
	};
}

#endif