#ifndef RAIN_TEXTEDIT
#define RAIN_TEXTEDIT

#include <string>
#include <Windows.h>
#include "ScrollBar.h"
#include "Window.h"

namespace Rain
{
	//For now, our character set will contain the characters inclusive: 32-126, 9 (TAB), 10 (NEWLINE). The only font allowed is "Courier New". The size can be changed though. Allow for CTRL+C, CTRL+X, CTRL+V, CTRL+A, SHIFT+LBUTTONDOWN, DRAG/SELECT, LEFT, RIGHT, UP, DOWN, BACKSPACE, DELETE. Do not handle SHIFT+UP/DOWN/LEFT/RIGHT. Do not allow newlines, tabs, UP, and DOWN in a single-line textedit. If CTRL+V contains invalid characters, trim the characters out, and paste the rest into the edit. This includes newlines, if we have a single-line textedit.
	//If there is a tab, right-shift by 4 spaces the entire paragraph which is tabbed. Do not allow tabs unless they come directly after a newline or another tab. When the user presses newline after a tabbed paragraph, automatically insert the identical number of tabs.
	//To capture 32-126, 9, 10, BACKSPACE, we need WM_CHAR.
	//To capture LEFT, RIGHT, UP, DOWN, DELETE, we need WM_KEYDOWN.
	//To capture SHIFT+LBUTTONDOWN, DRAG/SELECT, we need WM_MOUSEMOVE, WM_LBUTTONDOWN, WM_LBUTTONUP.
	//To capture CRTL+C, CTRL+X, CTRL+V, CTRL+A, we need WM_HOTKEY.
	//For painting, we need WM_ERASEBKGND, WM_PAINT.
	//We also need to handle WM_SCROLLBARSCROLL from the scrollbar, and WM_MOUSEWHEEL to pass to our scrollbar.
	//WM_KILLFOCUS and WM_SETFOCUS will be needed for caret operations.
	class TextEdit : public Window
	{
		public:
			TextEdit ();
			~TextEdit ();

			void	Initialize	(HWND parent, bool multi_line = true); //Option to be a single-line text edit. There's really no point in allowing this to be changable.
			void	Destroy		();

			//Usable only after initialization (protected by assert). All variables have default values.
			void	SetFontSize			(int size); //We aren't going to allow typeface changing yet. It's going to be Courier New.
			void	SetText				(std::string new_text); //Resets line_pos to the end; we won't be using this as the user is typing anyway.
			void	SetScrollWidth		(int width);
			void	SetScrollInterval	(int interval);

			std::string	GetText	();

			//Leave SetParent availible in case the user wants to change the parent.

		private:
			LRESULT	OnChar				(WPARAM wparam, LPARAM lparam);
			LRESULT	OnEraseBkgnd		(WPARAM wparam, LPARAM lparam);
			LRESULT	OnHotKey			(WPARAM wparam, LPARAM lparam);
			LRESULT	OnKeyDown			(WPARAM wparam, LPARAM lparam);
			LRESULT	OnKillFocus			(WPARAM wparam, LPARAM lparam);
			LRESULT	OnLButtonUp			(WPARAM wparam, LPARAM lparam);
			LRESULT	OnLButtonDown		(WPARAM wparam, LPARAM lparam);
			LRESULT	OnMouseMove			(WPARAM wparam, LPARAM lparam);
			LRESULT	OnMouseWheel		(WPARAM wparam, LPARAM lparam);
			LRESULT	OnPaint				(WPARAM wparam, LPARAM lparam);
			LRESULT	OnScrollBarScroll	(WPARAM wparam, LPARAM lparam);
			LRESULT	OnSetFocus			(WPARAM wparam, LPARAM lparam);
			LRESULT	OnSize				(WPARAM wparam, LPARAM lparam);

			Window::SetUserData;
			Window::SetLargeIcon;
			Window::SetSmallIcon;
			Window::SetExStyle;
			Window::SetStyle;
			Window::SetTitleText;
			Window::BeginOffScreenDC;
			Window::EndOffScreenDC;
			Window::BeginPaint;
			Window::EndPaint;
			Window::GetUserData;
			Window::GetParent;
			Window::GetWindow;
			Window::RedefineMessage;
			Window::ClearMessages;

			const int	CARETWIDTH;
			const int	XSHIFT;
			const int	YSHIFT;

			Rain::ScrollBar scroll; //Updated by SetFontSize, SetText (scroll to bottom), SetScrollWidth, SetScrollInterval, OnChar, OnHotKey, OnKeyDown, OnMouseMove, OnMouseWheel, OnSize.
			HFONT font; //Updated by SetFontSize.
			std::string text; //Updated by SetText, OnChar, OnHotKey, OnKeyDown.
			double y_space; //Space between lines to balance space distribution. Updated by SetFontSize, OnSize.
			int line_pos, //The line we are currently scrolled to (top of screen). Updated by SetFontSize, SetText, Initialize, or OnSize is called.
				caret_pos, //Position of the insertion caret.
				sel_pivot, //Selection pivot point. This & caret_pos make a selection.
				char_x, char_y, //Height and width of every character of the font. Update this when SetFontSize, Initialize, or OnSize is called.
				view, total, //Lines. Update this when SetFontSize, Initialize, or OnSize is called.
				char_pline; //Characters per line. Update this when SetFontSize, Initialize, or OnSize is called.
			bool multi_line, 
				tracking;
	};
}

#endif