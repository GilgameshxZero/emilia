#include <cassert>
#include <string>
#include <Windows.h>
#include <windowsx.h>
#include "Button.h"
#include "Window.h"

namespace Rain
{
	Button::Button () : 
		NORMAL (0), 
		HOVER (1), 
		DRAG (2), 
		DOWN (3)
	{
	}
	Button::~Button ()
	{
	}

	void Button::Initialize (HWND parent)
	{
		Window::Initialize (CS_HREDRAW | CS_VREDRAW);
		SetStyle (WS_CHILD);
		SetParent (parent);
		
		RedefineMessage (WM_PAINT, static_cast<LRESULT (Rain::Window::*) (WPARAM, LPARAM)>(&Button::OnPaint));
		RedefineMessage (WM_LBUTTONUP, static_cast<LRESULT (Rain::Window::*) (WPARAM, LPARAM)>(&Button::OnLButtonUp));
		RedefineMessage (WM_LBUTTONDOWN, static_cast<LRESULT (Rain::Window::*) (WPARAM, LPARAM)>(&Button::OnLButtonDown));
		RedefineMessage (WM_MOUSEMOVE, static_cast<LRESULT (Rain::Window::*) (WPARAM, LPARAM)>(&Button::OnMouseMove));
		RedefineMessage (WM_ERASEBKGND, static_cast<LRESULT (Rain::Window::*) (WPARAM, LPARAM)>(&Button::OnEraseBkgnd));

		//Default local variables (and reset them in some cases).
		normal_color = RGB (50,50,50);
		hover_color = RGB (60,60,60);
		drag_color = RGB (110,60,60);
		down_color = RGB (60,60,110);
		font = "Courier New";
		font_size = 12;
		state = NORMAL;
		text = "";
	}
	void Button::Destroy ()
	{
		Window::Destroy ();
	}

	void Button::SetText (std::string new_text)
	{
		assert (GetWindow ());
		text = new_text;

		//Unconditional redraw because we don't have anything limiting our redraw.
		Redraw ();
	}
	void Button::SetFont (std::string new_font)
	{
		assert (GetWindow ());
		font = new_font;

		Redraw ();
	}
	void Button::SetFontSize (int new_size)
	{
		assert (GetWindow ());
		font_size = new_size;

		Redraw ();
	}
	void Button::SetColors (COLORREF normal_color, COLORREF hover_color, COLORREF drag_color, COLORREF down_color)
	{
		assert (GetWindow ());

		normal_color = normal_color;
		hover_color = hover_color;
		drag_color = drag_color;
		down_color = down_color;

		Redraw ();
	}
	
	LRESULT Button::OnLButtonUp (WPARAM wparam, LPARAM lparam)
	{
		RECT wnd_rect;

		::GetClientRect (GetWindow (), &wnd_rect);

		if (GetWindow () == ::GetCapture ())
			::ReleaseCapture ();

		//Button pressed. Pass this object as the WPARAM so that the parent can tell which button returned this message.
		if (state == DOWN && GET_X_LPARAM (lparam) >= 0 && GET_X_LPARAM (lparam) <= wnd_rect.right - wnd_rect.left && GET_Y_LPARAM (lparam) >= 0 && GET_Y_LPARAM (lparam) <= wnd_rect.bottom - wnd_rect.top)
			::SendMessage (GetParent (), WM_BUTTONPRESS, reinterpret_cast<WPARAM>(this), NULL);

		state = NORMAL;
		Redraw ();

		return static_cast<LRESULT>(0);
	}
	LRESULT Button::OnLButtonDown (WPARAM wparam, LPARAM lparam)
	{
		::SetFocus (GetWindow ());
		state = DOWN;
		Redraw ();

		return static_cast<LRESULT>(0);
	}
	LRESULT Button::OnMouseMove (WPARAM wparam, LPARAM lparam)
	{
		RECT wnd_rect;

		::GetClientRect (GetWindow (), &wnd_rect);

		if (state == NORMAL)
		{
			state = HOVER;
			Redraw ();

			if (!(GetWindow () == ::GetCapture ()))
				::SetCapture (GetWindow ());
		}
		else if (state == HOVER && !(GET_X_LPARAM (lparam) >= 0 && GET_X_LPARAM (lparam) <= wnd_rect.right - wnd_rect.left && GET_Y_LPARAM (lparam) >= 0 && GET_Y_LPARAM (lparam) <= wnd_rect.bottom - wnd_rect.top))
		{
			state = NORMAL;
			Redraw ();

			if (GetWindow () == ::GetCapture ())
				::ReleaseCapture ();
		}
		else if (state == DRAG && GET_X_LPARAM (lparam) >= 0 && GET_X_LPARAM (lparam) <= wnd_rect.right - wnd_rect.left && GET_Y_LPARAM (lparam) >= 0 && GET_Y_LPARAM (lparam) <= wnd_rect.bottom - wnd_rect.top)
		{
			state = DOWN;
			Redraw ();
		}
		else if (state == DOWN && !(GET_X_LPARAM (lparam) >= 0 && GET_X_LPARAM (lparam) <= wnd_rect.right - wnd_rect.left && GET_Y_LPARAM (lparam) >= 0 && GET_Y_LPARAM (lparam) <= wnd_rect.bottom - wnd_rect.top))
		{
			state = DRAG;
			Redraw ();
		}

		return static_cast<LRESULT>(0);
	}
	LRESULT Button::OnEraseBkgnd (WPARAM wparam, LPARAM lparam) //Purely for drawing purposes.
	{
		return static_cast<LRESULT>(1);
	}
	LRESULT Button::OnPaint (WPARAM wparam, LPARAM lparam)
	{
		HDC dc;

		BeginPaint ();
		dc = BeginOffScreenDC ();

		RECT wnd_rect;

		::GetClientRect (GetWindow (), &wnd_rect);

		//Create the brush based on the state.
		HBRUSH brush;

		if (state == NORMAL)
			brush = ::CreateSolidBrush (normal_color);
		else if (state == HOVER)
			brush = ::CreateSolidBrush (hover_color);
		else if (state == DRAG)
			brush = ::CreateSolidBrush (drag_color);
		else if (state == DOWN)
			brush = ::CreateSolidBrush (down_color);

		//Create font based on local variables.
		HFONT hfont = ::CreateFont (-MulDiv (font_size, GetDeviceCaps (dc, LOGPIXELSY), 72), 0, 0, 0, 0, false, false, false, 0, 0, 0, 0, 0, font.c_str ());

		//Standard initialization.
		::SetTextColor (dc, RGB (0,0,0));
		::SetBkMode (dc, TRANSPARENT);
		HBRUSH orig_brush = reinterpret_cast<HBRUSH>(SelectObject (dc, brush));
		HFONT orig_font = reinterpret_cast<HFONT>(SelectObject (dc, hfont));

		//Now that the dc is all initialized, we can start drawing.
		::Rectangle (dc, 0, 0, wnd_rect.right - wnd_rect.left, wnd_rect.bottom - wnd_rect.top);

		SIZE tsize;

		::GetTextExtentPoint32 (dc, text.c_str (), static_cast<int>(text.length ()), &tsize);
		::TextOut (dc, (wnd_rect.right - wnd_rect.left - tsize.cx) / 2, (wnd_rect.bottom - wnd_rect.top - tsize.cy) / 2, text.c_str (), static_cast<int>(text.length ()));
		
		//Free stuff up.
		::SelectObject (dc, orig_brush);
		::SelectObject (dc, orig_font);
		::DeleteObject (brush);
		::DeleteObject (hfont);

		EndOffScreenDC ();
		EndPaint ();

		return static_cast<LRESULT>(0);
	}
}