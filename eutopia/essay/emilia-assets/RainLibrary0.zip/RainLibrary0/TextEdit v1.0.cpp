#include <sstream>
#include <string>
#include <Windows.h>
#include <WindowsX.h>
#include "TextEdit.h"
#include "Window.h"

namespace RainCorporation
{
	namespace TextEdit
	{
		const int	BORDERXDIST	= 12;
		const int	BORDERYDIST	= 8;

		TextEdit::TextEdit (void)
		{
			state = "Normal";
			parent_wnd = edit_wnd = NULL;
			font = NULL;
			cx = cy = font_size = 0;
			text = "";
		}

		void TextEdit::Initialize (HWND parent_wnd, int cx, int cy, std::string style, int fontsize, std::string font)
		{
			static int identifier; //Use this variable to create unique class names.
			std::stringstream sstream;
			std::string EditClassName_str;
			LPCSTR EditClassName, EditTitleText;

			sstream << "RainCorporation::TextEdit: " << identifier++;
			EditClassName_str = sstream.str ();
			EditClassName = EditTitleText = EditClassName_str.c_str ();

			this->edit_wnd = RainCorporation::Window::InitializeWindow (ButtonProc, reinterpret_cast<HINSTANCE>(GetWindowLongPtr (parent_wnd, GWLP_HINSTANCE)), EditClassName, EditTitleText, WS_CHILD, cx, cy, this, parent_wnd, reinterpret_cast<HBRUSH>(COLOR_WINDOW + 1), WS_EX_NOPARENTNOTIFY);

			if (style == "Left")
				this->text_edit = RainCorporation::Window::InitializeWindow (NULL, reinterpret_cast<HINSTANCE>(GetWindowLongPtr (parent_wnd, GWLP_HINSTANCE)), "", "", WS_CHILD | ES_LEFT, cx - BORDERXDIST * 2 - 2, cy - BORDERYDIST * 2, NULL, this->edit_wnd, NULL, NULL, NULL, NULL, "EDIT");
			else if (style == "Center") //Not fully implemented.
				this->text_edit = RainCorporation::Window::InitializeWindow (NULL, reinterpret_cast<HINSTANCE>(GetWindowLongPtr (parent_wnd, GWLP_HINSTANCE)), "", "", WS_CHILD | ES_CENTER, cx - BORDERXDIST * 2 - 2, cy - BORDERYDIST * 2, NULL, this->edit_wnd, NULL, NULL, NULL, NULL, "EDIT");
			else if (style == "Right") //Not fully implemented.
				this->text_edit = RainCorporation::Window::InitializeWindow (NULL, reinterpret_cast<HINSTANCE>(GetWindowLongPtr (parent_wnd, GWLP_HINSTANCE)), "", "", WS_CHILD | ES_RIGHT, cx - BORDERXDIST * 2 - 2, cy - BORDERYDIST * 2, NULL, this->edit_wnd, NULL, NULL, NULL, NULL, "EDIT");

			//Copy all parameters and properties to local storage.
			this->parent_wnd = parent_wnd;
			this->cx = cx;
			this->cy = cy;
			this->font_size = fontsize;
			
			this->font = CreateFont (-MulDiv (this->font_size, GetDeviceCaps (GetDC (this->text_edit), LOGPIXELSY), 72), 0, 0, 0, 0, false, false, false, 0, 0, 0, 0, 0, font.c_str ());
			SendMessage (this->text_edit, WM_SETFONT, reinterpret_cast<WPARAM>(this->font), NULL);
			MoveWindow (this->text_edit, BORDERXDIST - 1, BORDERYDIST, cx - BORDERXDIST * 2 - 2, cy - BORDERYDIST * 2, false);
			ShowWindow (this->edit_wnd, SW_HIDE);
			ShowWindow (this->text_edit, SW_HIDE);

			return;
		}

		std::string TextEdit::GetText ()
		{
			return this->text;
		}
		bool TextEdit::SetText (std::string new_string)
		{
			LPTSTR c_str;

			this->text = new_string;
			c_str = const_cast<char *>(this->text.c_str ()); //Potentially unsafe (Unicode?) -- update in future releases.
			Edit_SetText (this->text_edit, c_str);

			return Draw ();
		}
		void TextEdit::Show (int x, int y)
		{
			this->state = "Normal";
			MoveWindow (edit_wnd, x, y, cx, cy, false);
			ShowWindow (edit_wnd, SW_SHOW);
		}
		void TextEdit::Hide ()
		{	
			state = "Hidden";
			ShowWindow (this->edit_wnd, SW_HIDE);
		}

		bool TextEdit::Draw ()
		{
			HPEN pen = CreatePen (PS_SOLID, 1, RGB (0,0,0)), orig_pen;
			HDC DCMem, DC = GetDC (this->edit_wnd);
			HBITMAP BMMem, BMOld;
			HBRUSH brush, orig_brush;
			int a, b, height;
			HFONT orig_font;
			SIZE tsize;
			RECT cRect;

			//Set up an off-screen DC.
			GetClientRect (this->edit_wnd, &cRect);

			DCMem = CreateCompatibleDC (DC);
			BMMem = CreateCompatibleBitmap (DC, cRect.right - cRect.left, cRect.bottom - cRect.top);
			BMOld = reinterpret_cast<HBITMAP>(SelectObject (DCMem, BMMem));

			FillRect (DCMem, &cRect, CreateSolidBrush (RGB (255,255,255)));

			//We only need to draw if we aren't active. If the text-edit is active, then we need to show that instead.
			if (this->state != "Active")
			{
				ShowWindow (this->text_edit, SW_HIDE);

				//Create the brush based on the state.
				if (state == "Normal")
					brush = CreateSolidBrush (RGB (230,230,230));
				else if (state == "Hover")
					brush = CreateSolidBrush (RGB (200,200,200));
				else if (state == "Drag")
					brush = CreateSolidBrush (RGB (255,150,150));
				else if (state == "Down")
					brush = CreateSolidBrush (RGB (150,150,255));

				SetTextColor (DCMem, RGB (0,0,0));
				SetBkMode (DCMem, TRANSPARENT);
				orig_brush = reinterpret_cast<HBRUSH>(SelectObject (DCMem, brush));
				orig_pen = reinterpret_cast<HPEN>(SelectObject (DCMem, pen));
				orig_font = reinterpret_cast<HFONT>(SelectObject (DCMem, this->font));

				//Draw the text. If we cannot fit this many letters in the edit, then return true. The caller will deal with the return value, and we just fit as many letters into the edit as possible.
				Rectangle (DCMem, 0, 0, cx, cy);
				Rectangle (DCMem, 3, 3, cx - 3, cy - 3);
				GetTextExtentPoint32 (DCMem, text.c_str (), static_cast<int>(text.length ()), &tsize);

				//Fill up a line at a time.
				for (a = 1, b = 0, height = tsize.cy;a < static_cast<int>(text.length ()) && height <= this->cy - BORDERYDIST * 2;a++)
				{
					GetTextExtentPoint32 (DCMem, text.substr (b, a - b).c_str (), a - b, &tsize);

					//Check if we can make a line, and print if we did.
					if (tsize.cx > this->cx - BORDERXDIST * 2)
					{
						TextOut (DCMem, BORDERXDIST, height - tsize.cy + BORDERYDIST, text.substr (b, a - b - 1).c_str (), a - b - 1);
						b = --a;
						height += tsize.cy;
					}
				}

				//We didn't finish the last line, print it now.
				if (a == text.length ())
					TextOut (DCMem, BORDERXDIST, height - tsize.cy + BORDERYDIST, text.substr (b, a - b).c_str (), a - b);
			
				//If we prematurely aborted the loop, that means we didn't finish displaying all the letters.
				if (a != text.length ())
				{
					//Off-screen DC.
					BitBlt (DC, cRect.left, cRect.top, cRect.right - cRect.left, cRect.bottom - cRect.top, DCMem, 0, 0, SRCCOPY);

					SelectObject (DCMem, orig_brush);
					SelectObject (DCMem, orig_pen);
					SelectObject (DCMem, orig_font);
					SelectObject (DCMem, BMOld);
					DeleteObject (BMMem);
					DeleteDC (DCMem);
					DeleteObject (brush);
					DeleteObject (pen);
					ReleaseDC (this->edit_wnd, DC);

					return true;
				}

				SelectObject (DCMem, orig_font);
			}
			else //Draw the border, white background, to blend in with the edit.
			{
				brush = CreateSolidBrush (RGB (255,255,255));
				orig_brush = reinterpret_cast<HBRUSH>(SelectObject (DCMem, brush));
				orig_pen = reinterpret_cast<HPEN>(SelectObject (DCMem, pen));
				Rectangle (DCMem, 0, 0, cx, cy);
				Rectangle (DCMem, 3, 3, cx - 3, cy - 3);

				ShowWindow (this->text_edit, SW_SHOW);
			}

			//Off-screen DC.
			BitBlt (DC, cRect.left, cRect.top, cRect.right - cRect.left, cRect.bottom - cRect.top, DCMem, 0, 0, SRCCOPY);

			SelectObject (DCMem, orig_brush);
			SelectObject (DCMem, orig_pen);
			SelectObject (DCMem, BMOld);
			DeleteObject (BMMem);
			DeleteDC (DCMem);
			DeleteObject (brush);
			DeleteObject (pen);
			ReleaseDC (this->edit_wnd, DC);

			return false;
		}

		void TextEdit::CheckMove (int x, int y)
		{
			if (this->state == "Normal")
			{
				this->state = "Hover";
				Draw ();

				if (this->edit_wnd != GetCapture ())
					SetCapture (this->edit_wnd);
			}
			else if (this->state == "Hover" && !(x >= 0 && x <= cx && y >= 0 && y <= cy))
			{
				this->state = "Normal";
				Draw ();

				if (this->edit_wnd == GetCapture ())
					ReleaseCapture ();
			}
			else if (this->state == "Drag" && x >= 0 && x <= cx && y >= 0 && y <= cy)
			{
				this->state = "Down";
				Draw ();
			}
			else if (this->state == "Down" && !(x >= 0 && x <= cx && y >= 0 && y <= cy))
			{
				this->state = "Drag";
				Draw ();
			}
		}
		void TextEdit::CheckUp (int x, int y)
		{
			if (this->edit_wnd == GetCapture ())
				ReleaseCapture ();

			if (this->state == "Down" && x >= 0 && x <= cx && y >= 0 && y <= cy)
			{
				this->state = "Active";
				SetFocus (this->text_edit);
				Draw ();
			}
			else if (this->state == "Hover" || this->state == "Drag")
			{
				this->state = "Normal";
				Draw ();
			}
		}
		void TextEdit::CheckDown (int x, int y)
		{
			if (this->state == "Hover")
			{
				this->state = "Down";
				Draw ();
			}
		}
		void TextEdit::CheckDeactivate ()
		{
			TCHAR c_str[256];
			std::wstringstream ss;
			std::wstring ws;

			//Update the this->text variable. (TODO: Lookup documentation on this, and improve stability.)
			Edit_GetText (this->text_edit, c_str, 256);
			ss << c_str;
			ws = ss.str ();
			this->text = std::string (ws.begin (), ws.end ());

			this->state = "Normal";
			Draw ();

			SendMessage (this->parent_wnd, WM_RAINCORPTEXTEDITCHANGE, NULL, NULL);
		}

		LRESULT CALLBACK ButtonProc (HWND button_wnd, UINT msg, WPARAM wparam, LPARAM lparam)
		{
			switch (msg)
			{
				case WM_CLOSE:
				{
					DestroyWindow (button_wnd);

					break;
				}

				case WM_COMMAND:
				{
					TextEdit *WndClass = reinterpret_cast<TextEdit *>(GetWindowLongPtr (button_wnd, GWLP_USERDATA));

					if (HIWORD (wparam) == EN_KILLFOCUS && reinterpret_cast<HWND>(lparam) == WndClass->text_edit)
						WndClass->CheckDeactivate ();

					break;
				}

				case WM_MOUSEMOVE:
				{
					TextEdit *WndClass = reinterpret_cast<TextEdit *>(GetWindowLongPtr (button_wnd, GWLP_USERDATA));
					WndClass->CheckMove (GET_X_LPARAM (lparam), GET_Y_LPARAM (lparam));
					break;
				}

				case WM_LBUTTONDOWN:
				{
					TextEdit *WndClass = reinterpret_cast<TextEdit *>(GetWindowLongPtr (button_wnd, GWLP_USERDATA));
					WndClass->CheckDown (GET_X_LPARAM (lparam), GET_Y_LPARAM (lparam));
					break;
				}

				case WM_LBUTTONUP:
				{
					TextEdit *WndClass = reinterpret_cast<TextEdit *>(GetWindowLongPtr (button_wnd, GWLP_USERDATA));
					WndClass->CheckUp (GET_X_LPARAM (lparam), GET_Y_LPARAM (lparam));
					break;
				}

				case WM_PAINT:
				{
					PAINTSTRUCT ps;
					TextEdit *WndClass = reinterpret_cast<TextEdit *>(GetWindowLongPtr (button_wnd, GWLP_USERDATA));

					BeginPaint (button_wnd, &ps);
					WndClass->Draw ();
					EndPaint (button_wnd, &ps);

					break;
				}

				default:
					return DefWindowProc(button_wnd, msg, wparam, lparam);
			}

			return static_cast<LRESULT>(0);
		}
	}
}